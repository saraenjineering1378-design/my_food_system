#include <iostream>
#include "DatabaseManager.h"
#include "DatabaseInitializer.h" // حتما این رو اینکلود کن

int main() {
    // ۱. ایجاد شیء از مدیریت دیتابیس
    DatabaseManager dbManager("restaurant_db.sqlite");

    // ۲. تلاش برای باز کردن دیتابیس
    if (dbManager.open()) {
        std::cout << "Database opened successfully! " << std::endl;

        // ۳. فراخوانی اینیشلایزر برای ساخت جدول‌ها
        // چون متد initialize رو static تعریف کردی، مستقیم با نام کلاس صداش می‌زنیم
        DatabaseInitializer::initialize(dbManager);
        std::cout << "Tables initialized/checked successfully! " << std::endl;

        // --- اینجا می‌تونی منطق اصلی برنامه‌ت رو بذاری ---
        std::cout << "\n--- Welcome to Food Delivery System ---" << std::endl;
        
        // مثلاً فعلاً برای تست:
        // AppController controller(dbManager);
        // controller.run();
        
        std::cout << "Press Enter to exit..." << std::endl;
        std::cin.get(); 

        // ۴. بستن دیتابیس در انتها
        dbManager.close();
    } else {
        std::cerr << "Error: Could not open the database! " << std::endl;
        return 1;
    }

    return 0;
}
