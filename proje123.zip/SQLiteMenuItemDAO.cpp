#include "SQLiteMenuItemDAO.h"
#include <string>

void SQLiteMenuItemDAO::addMenuItem(int restaurantId, MenuItem* item)
{
    int typeNum = 3;
    if (dynamic_cast<DessertItem*>(item)) typeNum = 1;
    else if (dynamic_cast<DrinkItem*>(item)) typeNum = 2;

    std::string sql =
        "INSERT INTO MenuItems (restaurantId, name, description, basePrice, isAvailable, type) VALUES (" +
        std::to_string(restaurantId) + ", '" +
        item->getName() + "', '" +
        item->getDescription() + "', " +
        std::to_string(item->getBasePrice()) + ", " +
        (item->getIsAvailable() ? "1" : "0") + ", " +
        std::to_string(typeNum) + ");";

    if (!dbManager.executeQuery(sql)) 
    {
        std::cerr << "addMenuItemToRestaurant failed\n";
        return;
    }
}


std::vector<MenuItem*> SQLiteMenuItemDAO::getMenuItemsByRestaurant(int restaurantId) 
{
    std::vector<MenuItem*> list;
    std::string sql = "SELECT * FROM MenuItems WHERE restaurantId = " + std::to_string(restaurantId) + ";";
    
    auto rows = dbManager.fetchAll(sql);

   
    for (size_t i = 0; i < rows.size(); ++i) 
    {
        std::map<std::string, std::string>& row = rows[i];
        
        int id = std::stoi(row["id"]);
        std::string name = row["name"];
        std::string desc = row["description"];
        double price = std::stod(row["basePrice"]);
        bool available = (std::stoi(row["isAvailable"]) != 0);
        int type = std::stoi(row["type"]);

        MenuItem* item = nullptr;

    
        //bool isVeg = std::stoi(row["isVegetarian"]) != 0;
        bool isVeg = false;
        if (type == 1) item = new DessertItem(ItemType::DESSERT, id, name, desc, price, available, 0.5);//polymorphism
        else if (type == 2) item = new DrinkItem(ItemType::DRINK, id, name, desc, price, available, 330.0, true);
        else item = new FoodItem(id, name, desc, price, available, 20, isVeg);


        if (!available) item->setIsAvailable(false);
        list.push_back(item);
    }
    return list;
}

void SQLiteMenuItemDAO::removeMenuItem(int id) 
{
    std::string sql = "DELETE FROM MenuItems WHERE id = " + std::to_string(id) + ";";
    dbManager.executeQuery(sql);
}
 
std::vector<MenuItem*> SQLiteMenuItemDAO::getAllMenuItems()
{
    std::vector<MenuItem*> list;
    std::string sql = "SELECT * FROM MenuItems;";
    auto rows = dbManager.fetchAll(sql);

    for (auto& row : rows) // for jadid
    {
        int id = std::stoi(row["id"]);
        std::string name = row["name"];
        std::string desc = row["description"];
        double price = std::stod(row["basePrice"]);
        bool available = (std::stoi(row["isAvailable"]) != 0);
        int type = std::stoi(row["type"]);

        MenuItem* item = nullptr;
        if (type == 1) item = new DessertItem(ItemType::DESSERT, id, name, desc, price, available, 0.5);
        else if (type == 2) item = new DrinkItem(ItemType::DRINK, id, name, desc, price, available, 330.0, true);
        else item = new FoodItem(id, name, desc, price, available, 20, false);

        list.push_back(item);
    }
    return list;
}

MenuItem* SQLiteMenuItemDAO::findMenuItemById(int id) 
{
    // فعلاً برای اینکه کامپایل بشه null برمی‌گردونیم
    return nullptr; 
}

