#include <iostream>
#include "Restaurant.h"
#include "MemoryMenuItemDAO.h"
#include "MemoryOrderDAO.h"
#include "MenuItem.h"
#include "Order.h"

using namespace std;

int main() {
    // ساخت DAOها
    IMenuItemDAO* menuDAO = new MemoryMenuItemDAO();
    IOrderDAO* orderDAO = new MemoryOrderDAO();

    // ساخت رستوران
    Restaurant myRest(
        1,
        "Pizza Land",
        "Tehran, Street 1",
        30,
        "021-123456",
        "Best Italian Pizza",
        true,
        menuDAO,
        orderDAO
    );

    // ساخت آیتم منو
    MenuItem* pizza = new MenuItem (
        ItemType::FOOD,
        50,
        "Pizza Margharita",
        "Classic Italian",
        200.0,
        true
    );

    // اضافه کردن آیتم به منو
    myRest.addMenuItem(pizza);

    // ساخت سفارش
    Order* newOrder = new Order(
        101,
        1,   // customerId
        1    // restaurantId
    );

    // اضافه کردن آیتم به سفارش
    newOrder->addItem(pizza);

    // ثبت سفارش
    myRest.addOrder(newOrder);

    // تست نمایش‌ها
    cout << "\n===== RESTAURANT INFO =====\n";
    myRest.displayRestaurantInfo();

    cout << "\n===== MENU =====\n";
    myRest.displayMenu();

    cout << "\n===== ORDERS =====\n";
    myRest.displayReceivedOrders();

    cout << "\n===== SINGLE ORDER =====\n";
    myRest.displayReceivedOrders();


    cout << "\n===== MENU ITEM BY ID =====\n";
    myRest.displayMenu();

    return 0;
}
