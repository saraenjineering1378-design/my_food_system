#ifndef IMENUITEMDAO_H
#define IMENUITEMDAO_H

#include <vector>
#include "MenuItem.h"

class IMenuItemDAO
{
public:

   virtual void addMenuItem(MenuItem* item) = 0;
   virtual MenuItem* findMenuItemById(int id) = 0;
   virtual std::vector<MenuItem*> getAllMenuItems() = 0;

   virtual void removeMenuItem(int itemId) = 0;
   virtual ~IMenuItemDAO() {} 



};
#endif