#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <vector>
#include <string>
#include  "Order.h"

class Customer
{
private:

    int CustomerID;
    std::string name;
    double Wallet;
    std::vector<Order*> OrderHistory;

public:

    Customer(int CustomerId, std::string name, double Wallet);

    ~Customer();

    //getterha
    int getCustomerId() const;
    std::string getName() const;
    double getWallet() const;


    void setName(std::string Name); // chon b motghayer private, mostaghim dastresi nadarim baray taviz nam az set kardan mirim

    
    //baray moshtariha
    void addFunds(double amount);   //sharj hesab        
    bool payForOrder(double amount); //pardakht sefaresh
    void addOrderToHistory(Order* order);  //ezafe kardan be history 
    void displayOrderHistory() const;     //namayesh list sefareshat

};
#endif