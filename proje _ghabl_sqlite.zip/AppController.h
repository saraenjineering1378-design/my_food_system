#ifndef APPCONTROLLER_H
#define APPCONTROLLER_H

#include "Restaurant.h"
#include "Customer.h"


class AppController
{
private:

    Restaurant& restaurant; 
    Customer customer;
    int nextOrderId; 
    
    
    void showAdminMenu();          //addmin
    void showRestaurantOwnerMenu();  //saheb resturan
    void showCustomerMenu();     // moshtari



    void adminManageRestaurantStatus(); // method jadid
    void adminAddMenuItem(); //kebetone saheb resturan be menu ezafe kone
    void customerChargeWallet();     // baray sharj kif pol
    void managerUpdateOrderStatus(); //baray taghir vaziyat sefaresh



    void adminAddFoodItem();
    void adminRemoveItem();
    void customerPlaceOrder();
    void removeMenuItemById(int id);



public:

    AppController(Restaurant& r); 


    void run();

};
#endif