#include "AppController.h"
#include "FoodItem.h"
#include <iostream>

AppController::AppController(Restaurant &r)
    : restaurant(r), customer(1, "Guest", 0.0), nextOrderId(1) {}

void AppController::run()
{
    int role = 0;
    while (role != 4)
    {
        std::cout << "\n=== Food Ordering System ===\n";
        std::cout << "1. Admin\n2. Restaurant Owner\n3. Customer\n4. Exit\nSelect an option: ";
        std::cin >> role;

        switch (role)
        {
        case 1:
            showAdminMenu();
            break;
        case 2:
            showRestaurantOwnerMenu();
            break;
        case 3:
            showCustomerMenu();
            break;
        case 4:
            std::cout << "Exiting system...\n";
            break;
        default:
            std::cout << "Invalid choice!\n";
            break;
        }
    }
}

// --- Admin Menu ---
void AppController::showAdminMenu()
{
    int choice = 0;
    while (choice != 3)
    {
        std::cout << "\n--- Admin Panel ---\n";
        std::cout << "1. Manage Restaurants (Activate/Deactivate)\n2. View General Report\n3. Back\nSelect: ";
        std::cin >> choice;

        if (choice == 1)
            std::cout << "Restaurant status updated.\n";
        else if (choice == 2)
            std::cout << "Report: Total Orders: " << (nextOrderId - 1) << " | Total Sales: Calculating...\n";
    }
}

// Restaurant Owner Menu 
void AppController::showRestaurantOwnerMenu() 
{
    int choice = 0;
    while (choice != 4) 
    {
        std::cout << "\n--- Restaurant Manager Panel ---\n";
        std::cout << "1. Manage Menu\n2. View Received Orders\n3. Update Order Status\n4. Back\nSelect: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
            { 
                std::cout << "1. Add Item\n2. Remove Item\nSelect: ";
                int sub; std::cin >> sub;
                if(sub == 1) adminAddFoodItem(); else adminRemoveItem();
                break;
            }
            case 2: 
                std::cout << "\n--- Received Orders ---\n";
                restaurant.displayReceivedOrders(); 
                break;
            case 3: // Update Order Status
            {
                restaurant.displayReceivedOrders(); // aval sefaresh haro bebine
                std::cout << "Enter order ID to update: ";
                int oId; std::cin >> oId;
                Order* ord = restaurant.findOrderId(oId);
                if(ord) 
                {
                    std::cout << "1. Preparing, 2. Delivered. Select: ";
                    int st; std::cin >> st;
                    if(st == 1) ord->updateStatus(OrderStatus::Preparing);
                    else if(st == 2) ord->updateStatus(OrderStatus::Delivered);
                    std::cout << "Status updated!\n";
                }
                 else
                {
                    std::cout << "Order not found!\n";
                }
                
    
                break;
            
            }
            case 4: break;
        }
    }
}


// Customer Menu
void AppController::showCustomerMenu() 
{
    int choice = 0;
    while (choice != 5) 
    {
        std::cout << "\n--- Customer Panel ---\n";
        std::cout << "Your Current Balance: $" << customer.getWallet() << "\n";  // namayesh mojodi kif pol
        std::cout << "1. View Restaurant Menu\n";
        std::cout << "2. Place Order\n";
        std::cout << "3. View Order History\n";
        std::cout << "4. Charge Wallet\n"; 
        std::cout << "5. Back to Main Menu\n";
        std::cout << "Select option: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
                if (!restaurant.getStatus()) {
                    std::cout << "Sorry! The restaurant is currently closed.\n";
                } else 
                {
                    restaurant.displayMenu();
                }
                break;
            
            case 2:
                if (!restaurant.getStatus()) {
                    std::cout << "Cannot place order! The restaurant is closed.\n";
                } else {
                     customerPlaceOrder(); 
                }
                break;
            
            case 3:
                customer.displayOrderHistory();
                break;
            
            case 4: 
            {
                //bakhsh jadid baray sharj kif pol
                double amount;
                std::cout << "Enter the amount to add to your wallet: $";
                std::cin >> amount;
                if (amount > 0) {
                    customer.addFunds(amount);
                    std::cout << "Wallet charged successfully! Your new balance: $" << customer.getWallet() << "\n";
                } else {
                    std::cout << "Invalid amount!\n";
                }
                break;
            }
            
            case 5:
                std::cout << "Returning to main menu...\n";
                break;
            
            default:
                std::cout << "Invalid choice! Please select 1-5.\n";
                break;
        }
    }
}


// method komaki
void AppController::adminAddFoodItem()
{
    int id, time;
    std::string name;
    double price;
    std::cout << "Enter ID, Name, Price, and Cooking Time: ";
    std::cin >> id >> name >> price >> time;
    restaurant.addMenuItem(new FoodItem(id, name, "Food", price, true, time, false));
}

void AppController::adminRemoveItem()
{
    int id;
    std::cout << "Enter Item ID: ";
    std::cin >> id;
    restaurant.removeMenuItem(id);
}

void AppController::customerPlaceOrder()
{

    // sakht sefaresh jadid
    Order *newOrder = new Order(nextOrderId, customer.getCustomerId(), restaurant.getId());
    int id;
    bool hasItems = false;

    while (true)
    {
        std::cout << "Enter Item ID (0 to finish): ";
        std::cin >> id;
        if (id == 0) break;

        MenuItem *item = restaurant.findMenuItem(id);
        if (item) {
            newOrder->addItem(item); // hesab kardan gheymat
            hasItems = true;
            std::cout << "Item added. Current Total: $" << newOrder->getTotalPrice() << "\n";
        } else {
            std::cout << "Item not found!\n";
        }
    }

    //chek kardan mojodi
    if (hasItems) {
        double total = newOrder->getTotalPrice();
        if (customer.payForOrder(total)) 
        {  
            restaurant.addOrder(newOrder);
            customer.addOrderToHistory(newOrder);
            nextOrderId++; 
            std::cout << "Order placed successfully!\n";
        } else {
            std::cout << "Order cancelled! Not enough money.\n";
            delete newOrder; // azad sazi hazeze
        }
    } 
    else 
    {
        delete newOrder;
    }
}



