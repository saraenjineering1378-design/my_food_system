#ifndef  ORDER_H
#define  ORDER_H

#include <string>
#include <vector>
#include "MenuItem.h"

enum class OrderStatus // baray jologiri az moshkelat 
{
    Pending,
    Preparing,
    Delivered,
    Cancelled
};


class Order
{
private:

    int orderId;
    int customerId;
    int restaurantId;
    std::vector<MenuItem*> items;
    OrderStatus status;
    double totalPrice;

public:

    Order(int orderId, int customerId, int restaurantId);

    ~Order();

    //getterha
    int getOrderId() const;
    int getCustomerId() const;
    int getRestaurantId() const;
    OrderStatus getStatus() const;
    double getTotalPrice() const;


    void addItem(MenuItem* item);
    void removeItem(int itemId);
    void updateStatus(OrderStatus newStatus); //taghir vaziyat sefaresh
    double calculateTotalPrice(); // mohesebe gheymat kol
    void displayOrderDetails() const; //namyesh joziyat sefaresh

    std::string statusToString() const; // tabdil b matn

};

#endif

