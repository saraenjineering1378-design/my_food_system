#ifndef MEMORYORDERDAO_H
#define MEMORYORDERDAO_H

#include "IOrderDAO.h"
#include "Order.h"
#include <vector>

class MemoryOrderDAO : public IOrderDAO {
private:
    std::vector<Order*> orders; 

public:

    void addOrder(Order* order) override {
        orders.push_back(order);
    }

    Order* findOrderById(int id) override {
        for (size_t i = 0; i < orders.size(); i++) 
        {
            if (orders[i]->getOrderId() == id) 
            {
                return orders[i];
            }
        }
        return nullptr; // yani peyda nashod
    }

    std::vector<Order*> getAllOrders() override {
        return orders;
    }

    ~MemoryOrderDAO() override//yeki bayad gardan begire delete kardano va in halat behtar hast
    {
        for (size_t i = 0; i < orders.size(); ++i)
        {
            delete orders[i]; // in ja tanha iaei hast ke shey ha delete mishan
        }
    orders.clear();
    }
   
};

#endif
