#ifndef MEMORYMENUITEMDAO_H
#define MEMORYMENUITEMDAO_H

#include "IMenuItemDAO.h"
#include <vector>
#include<algorithm>

class MemoryMenuItemDAO : public IMenuItemDAO
{
private:

    std::vector<MenuItem*> menuItems; // baray list ghazaha


public:

    void addMenuItem(MenuItem* item)  override
    {
        menuItems.push_back(item);
    }

    MenuItem* findMenuItemById(int id) override
    {
        for (size_t i = 0; i < menuItems.size(); i++)
        {
            if (menuItems[i] != nullptr && menuItems[i]->getId() == id)
            {
                return menuItems[i];
            }
        }
         return nullptr;
    }
    std::vector<MenuItem*> getAllMenuItems() override
    {
        return menuItems;
    }

    ~MemoryMenuItemDAO() override //baray delete malek shod DAO
    {

    for (size_t i = 0; i < menuItems.size(); ++i)
    {
        delete menuItems[i];
    }

    menuItems.clear();
    }

    void removeMenuItem(int itemId) override
    {
        menuItems.erase(
        std::remove_if(menuItems.begin(), menuItems.end(),
            [itemId](MenuItem* item) {
                if (item->getId() == itemId) {
                    delete item; // inja vaghean pak mishe
                    return true;
                }
                return false;
            }),
        menuItems.end());
}

};
#endif