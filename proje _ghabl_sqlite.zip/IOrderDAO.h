//harkasi ke edeaye modiriyat dare bayad in haro piyade sazi bokone
#ifndef IORDERDAO_H
#define IORDERDAO_H

#include "Order.h"
#include <vector>

class IOrderDAO
{
public:

    virtual ~IOrderDAO(){}// mokhareb baray class hay farzand baray modiriyat hafeze

    virtual void addOrder(Order* order) = 0;
    virtual Order* findOrderById(int id) = 0;
    virtual std::vector<Order*> getAllOrders() = 0;

};
#endif