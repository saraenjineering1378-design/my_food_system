#include "Customer.h"
#include <iostream>


Customer::Customer(int CustomerId, std::string name, double Wallet)
    : CustomerID(CustomerId), name(name), Wallet(Wallet)
{
}


Customer::~Customer()
{

/* for (size_t i = 0; i < OrderHistory.size(); ++i) 
    {
        delete OrderHistory[i]; //azad kardan hafeze har sefaresh
    }
    *///chon delete ro be memoryorderdao sepordim
    OrderHistory.clear();
}



int Customer::getCustomerId() const 
{
     return CustomerID; 
}
std::string Customer::getName() const 
{ 
    return name;
}
double Customer::getWallet() const 
{ 
    return Wallet; 
}


void Customer::setName(std::string Name) 
{ 
    name = Name; 
}


void Customer::addFunds(double amount)
{
    if (amount > 0) // poli ke mikhay berizi bayad + bashad
    {
        Wallet += amount;
        std::cout << "Account charged successfully. New balance: " << Wallet << std::endl;
    }
}


bool Customer::payForOrder(double amount)
{
    if (Wallet >= amount) {
        Wallet -= amount;
        std::cout << "Payment successful! Remaining balance: " << Wallet << std::endl;
        return true;
    } 
    else 
    {
        std::cout << "Insufficient funds! Please charge your wallet." << std::endl;
        return false;
    }
}


void Customer::addOrderToHistory(Order* order)
{
    OrderHistory.push_back(order);
}


void Customer::displayOrderHistory() const
{
    std::cout << "Order History for " << name << ":" << std::endl;
    for (size_t i = 0; i < OrderHistory.size(); ++i) {
        std::cout << "Order " << i + 1 << ":" << std::endl;
        OrderHistory[i]->displayOrderDetails(); 
        std::cout << "--------------------" << std::endl;
    }
}
