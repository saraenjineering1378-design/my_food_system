#include "ICustomerDAO.h"
#include "Customer.h"

class MemoryCustomerDAO : public ICustomerDAO
{
private:

     std::vector<Customer*> customers;

public:

    void addCustomer(Customer* c) override 
    {
        customers.push_back(c);
    }

    Customer* findCustomerById(int id) const override 
    {
        for (size_t i = 0; i < customers.size(); i++) 
        {
            if (customers[i]->getCustomerId() == id) 
            {
                return customers[i];
            }
        }
        return nullptr;
    }

    std::vector<Customer*> getAllCustomers() const override 
    {
        return customers;
    }

    ~MemoryCustomerDAO() 
    {
        for (size_t i = 0; i < customers.size(); i++) 
        {
            delete customers[i];
        }
        customers.clear();
    }

};