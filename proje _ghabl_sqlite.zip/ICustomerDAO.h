#ifndef ICUSTOMERDAO_H
#define ICUSTOMERDAO_H


#include "Customer.h"
#include <vector>

class ICustomerDAO 
{
public:

    virtual ~ICustomerDAO() {}
    virtual void addCustomer(Customer* customer) = 0;
    virtual Customer* findCustomerById(int id) const = 0;
    virtual std::vector<Customer*> getAllCustomers() const = 0;

};
#endif