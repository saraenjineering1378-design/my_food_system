#ifndef IRESTAURANTDAO_H
#define IRESTAURANTDAO_H

#include "Restaurant.h"
#include <vector>


class IRestaurantDAO
{

public:

    virtual ~IRestaurantDAO() {}
    virtual void addRestaurant(Restaurant* restaurant) = 0;
    virtual Restaurant* findRestaurantById(int id) const = 0;
    virtual std::vector<Restaurant*> getAllRestaurants() const = 0;
};
#endif