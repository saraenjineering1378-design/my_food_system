#include "AppController.h"
#include "FoodItem.h"
#include <iostream>
#include "DatabaseInitializer.h"

AppController::AppController(DatabaseManager& db) : dbManager(db), currentCustomer(nullptr) 
{
    // age jadval ha vojod nadaran misazim
    DatabaseInitializer::initialize(dbManager);

    // jay gozin kardan sqlite b jay memory
    restaurantDAO = new SQLiteRestaurantDAO(dbManager);
    customerDAO = new SQLiteCustomerDAO(dbManager);
    menuItemDAO = new SQLiteMenuItemDAO(dbManager);
    orderDAO = new SQLiteOrderDAO(dbManager);

    
}


void AppController::addRestaurant(Restaurant* r) //ezafe kardan resturan
{
    if (!r) return;
    restaurantDAO->addRestaurant(r);   //ham insert ham setid
    restaurants.push_back(r);          // va bad ham toy list hafeze negah midarim
}

void AppController::run()
{
    int role = 0;
    while (role != 4)
    {
        std::cout << "\n=== Food Ordering System ===\n";
        std::cout << "1. Admin\n2. Restaurant Owner\n3. Customer\n4. Exit\nSelect an option: ";
        std::cin >> role;

        switch (role)
        {
        case 1:
            showAdminMenu();
            break;
        case 2:
            for(size_t i=0; i<restaurants.size(); ++i) std::cout << i+1 << ". " << restaurants[i]->getName() << "\n";
            int idx; std::cin >> idx;
            if(idx > 0 && idx <= (int)restaurants.size()) showRestaurantOwnerMenu(restaurants[idx-1]);
            break;
        case 3:
            showCustomerMenu();
            break;
        case 4:
            std::cout << "Exiting system...\n";
            break;
        default:
            std::cout << "Invalid choice!\n";
            break;
        }
    }
}

//Admin Menu 
void AppController::showAdminMenu()
{
    int choice = 0;
    while (choice != 3)
    {
        std::cout << "\n--- Admin Panel ---\n";
        std::cout << "1. Manage Restaurants (Activate/Deactivate)\n2. View General Report\n3. Back\nSelect: ";
        std::cin >> choice;

        if (choice == 1)
            std::cout << "Restaurant status updated.\n";
        else if (choice == 2)
            std::cout << "Report: Total Orders: " << (nextOrderId - 1) << " | Total Sales: Calculating...\n";
    }
}

// Restaurant Owner Menu 
void AppController::showRestaurantOwnerMenu(Restaurant* restaurant) 
{
    int choice = 0;
    while (choice != 4) 
    {
        std::cout << "\n--- Restaurant Manager Panel ---\n";
        std::cout << "1. Manage Menu\n2. View Received Orders\n3. Update Order Status\n4. Back\nSelect: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
            { 
                std::cout << "1. Add Item\n2. Remove Item\nSelect: ";
                int sub; std::cin >> sub;
                if(sub == 1) adminAddFoodItem(restaurant); else adminRemoveItem(restaurant);
                break;
            }
            case 2: 
                std::cout << "\n--- Received Orders ---\n";
                restaurant->displayReceivedOrders();
                break;
            case 3: // Update Order Status
            {
                restaurant->displayReceivedOrders(); // aval sefaresh haro bebine
                std::cout << "Enter order ID to update: ";
                int oId; std::cin >> oId;
                Order* ord = restaurant->findOrderId(oId); 
                if(ord) 
                {
                    std::cout << "1. Preparing, 2. Delivered. Select: ";
                    int st; std::cin >> st;
                    if(st == 1) ord->updateStatus(OrderStatus::Preparing);
                    else if(st == 2) ord->updateStatus(OrderStatus::Delivered);
                    std::cout << "Status updated!\n";
                }
                 else
                {
                    std::cout << "Order not found!\n";
                }
                
    
                break;
            
            }
            case 4: break;
        }
    }
}


// Customer Menu
void AppController::showCustomerMenu() 
{
    if (restaurants.empty()) 
    {
        std::cout << "Sorry! There are no restaurants available." << std::endl;
        return;
    }

    std::cout << "\n--- Select a Restaurant ---\n";// baray entekhab resturan mored nazar
    for (size_t i = 0; i < restaurants.size(); i++) {
        std::cout << i + 1 << ". " << restaurants[i]->getName() << "\n"
        << " (address " << restaurants[i]->getAddress() << ")" << std::endl;
    }

    std::cout << "0. Back to Main Menu\n";

    int restChoice;
    std::cout << "Select option: ";
    std::cin >> restChoice;

    if (restChoice == 0) return; // bargasht be menu asli

    // motabar bodan entekhab karbar
    if (restChoice < 1 || restChoice > restaurants.size()) //etebar sanji entekhab karbar
    {
        std::cout << "Invalid choice!\n";
        return;
    }

    // restrran entekhab shode ro bardar
    Restaurant* selected= restaurants[restChoice - 1];


    int choice = 0;
    while (choice != 5) 
    {
        std::cout << "\n--- Customer Panel ---\n";
        std::cout << "Your Current Balance: $" << currentCustomer->getWallet() << "\n";  // namayesh mojodi kif pol
        std::cout << "1. View Restaurant Menu\n";
        std::cout << "2. Place Order\n";
        std::cout << "3. View Order History\n";
        std::cout << "4. Charge Wallet\n"; 
        std::cout << "5. Back to Main Menu\n";
        std::cout << "Select option: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
                if (!selected->getStatus()) 
                {
                    std::cout << "Sorry! The restaurant is currently closed.\n";
                } else 
                {
                    selected->displayMenu();
                }
                break;
            
            case 2:
                if (!selected->getStatus()) 
                {
                    std::cout << "Cannot place order! The restaurant is closed.\n";
                } else 
                {
                    customerPlaceOrder(selected); 
                }
                break;
            
            case 3:
                currentCustomer->displayOrderHistory();
                break;
            
            
            case 4: 
            {
                //bakhsh jadid baray sharj kif pol
                double amount;
                std::cout << "Enter the amount to add to your wallet: $";
                std::cin >> amount;
                if (amount > 0) {
                    currentCustomer->addFunds(amount);
                    std::cout << "Wallet charged successfully! Your new balance: $" << currentCustomer->getWallet() << "\n";
                } else {
                    std::cout << "Invalid amount!\n";
                }
                break;
            }
            
            
            case 5:
            {
                std::cout << "Returning to main menu...\n";
                break;
            }
            
            default:
            {
                std::cout << "Invalid choice! Please select 1-5.\n";
                break;
            }
        }
    
    }
}


// method komaki
void AppController::adminAddFoodItem(Restaurant* restaurant)
{
    int id, time;
    std::string name;
    double price;
    std::cout << "Enter ID, Name, Price, and Cooking Time: ";
    std::cin >> id >> name >> price >> time;
    restaurant->addMenuItem(restaurant->getId(), new FoodItem(id, name, "Delicious food", price, true, time, false));

}

void AppController::adminRemoveItem(Restaurant* restaurant)
{
    int id;
    std::cout << "Enter Item ID: ";
    std::cin >> id;
    restaurant->removeMenuItem(id);
}

    void AppController::customerPlaceOrder(Restaurant* restaurant)
{
    Order *newOrder = new Order(nextOrderId, currentCustomer->getCustomerId(), restaurant->getId());
    int id;
    bool hasItems = false;

    // entekhab ghazaha
    while (true)
    {
        std::cout << "Enter Item ID (0 to finish): ";
        std::cin >> id;
        if (id == 0) break;

        MenuItem *item = restaurant->findMenuItem(id);
        if (item) {
            newOrder->addItem(item);
            hasItems = true;
            std::cout << "Item added. Current Total: $" << newOrder->getTotalPrice() << "\n";
        } else {
            std::cout << "Item not found!\n";
        }
    }

    // agar chizi entekhab nashode bod bargard
    if (!hasItems) {
        delete newOrder;
        return;
    }

    //taeid nahaei
    std::cout << "\n--- Final Order Confirmation ---\n";
    std::cout << "Total Price: $" << newOrder->getTotalPrice() << "\n";
    std::cout << "Are you sure you want to place this order? (1 for Yes, 0 for No): ";
    int confirm;
    std::cin >> confirm;

    // age enseraf dad karbar pak kon va bargard
    if (confirm != 1) 
    {
        std::cout << "Order cancelled by user.\n";
        delete newOrder; 
        return;
    }

    // pardakht kardan
    double total = newOrder->getTotalPrice();
    if (currentCustomer->payForOrder(total)) 
    {  
        // age pardakht movafagh bod
        restaurant->addOrder(newOrder); // ezafe kardan b list sefareshat
        currentCustomer->addOrderToHistory(newOrder); // ezafe kardan b tarikhche moshtari
        nextOrderId++; // shomare sefaresh badi
        std::cout << "Order placed successfully! Enjoy your meal! :)\n";
    
    } else {
        // age pardakht movafagh nabod
        std::cout << "Order failed: Insufficient balance in wallet!\n";
        delete newOrder; // chon sefaresh nahaei nashod pas  pak mikonim
    }
}

AppController::~AppController() //pak kardan resturan ha
{
    
    for (size_t i = 0; i < restaurants.size(); i++) 
    {
        if (restaurants[i] != nullptr) // age null nabod ->
        {
            delete restaurants[i];
            restaurants[i] = nullptr;
        }
    }
    restaurants.clear();

    
    if (restaurantDAO) 
    {
        delete restaurantDAO;
        restaurantDAO = nullptr; // baray amniyat bishtar esharegar ro null mikonim
    }
    
    if (customerDAO) 
    {
        delete customerDAO;
        customerDAO = nullptr;
    }
    
    if (menuItemDAO) 
    {
        delete menuItemDAO;
        menuItemDAO = nullptr;
    }
    
    if (orderDAO) 
    {
        delete orderDAO;
        orderDAO = nullptr;
    }

}



void AppController::runRestaurantManagerPanel(Restaurant* restaurant) //safhe modir resturan
{
    int choice;
    while (true) 
    {
        std::cout << "\n==================================" << std::endl;
        std::cout << "   MANAGER PANEL: " << restaurant->getName() << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Edit Restaurant Info" << std::endl;
        std::cout << "2. Manage Menu (Add/Edit/Remove Items)" << std::endl;
        std::cout << "3. View & Process Incoming Orders" << std::endl;
        std::cout << "4. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 4) break;

        switch (choice) 
        {
            case 1: editRestaurantInfo(restaurant); break;
            case 2: manageRestaurantMenu(restaurant); break;
            case 3: viewRestaurantOrders(restaurant); break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    }
}

void AppController::manageRestaurantMenu(Restaurant* restaurant) 
{
    int choice;
    std::cout << "\n--- Menu Management ---" << std::endl;
    std::cout << "1. Add New Food" << std::endl;
    std::cout << "2. Remove Item" << std::endl;
    std::cout << "3. Back" << std::endl;
    std::cin >> choice;

    if (choice == 1) 
    {
        std::string name;
        double price;
        std::cout << "Enter Food Name: ";
        std::cin.ignore();
        std::getline(std::cin, name);
        std::cout << "Enter Price: ";
        std::cin >> price;

        MenuItem* newItem = new FoodItem(0, name, "No description", price, true, 20, false);

        
        menuItemDAO->addMenuItem(restaurant->getId(), newItem);//vasl be data base

        
        std::cout << "Item added successfully!" << std::endl;
    } 
    else if (choice == 2) {
        restaurant->displayMenu();
        int id;
        std::cout << "Enter Item ID to remove: ";
        std::cin >> id;
        restaurant->removeMenuItem(id);
        menuItemDAO->removeMenuItem(id); //vasl b data base
    }
}


void AppController::viewRestaurantOrders(Restaurant* restaurant) 
{
    restaurant->displayReceivedOrders(); // in metod dar class restaurant darim
    
    int orderId;
    std::cout << "\nEnter Order ID to update status (or 0 to back): ";
    std::cin >> orderId;

    if (orderId != 0) 
    {
        Order* order = restaurant->findOrderId(orderId);
        if (order) 
        {
            int statusChoice;
            std::cout << "Choose Status: 1. Preparing 2. Delivered 3. Cancelled: ";
            std::cin >> statusChoice;
            
            std::string newStatus = (statusChoice == 1) ? "Preparing" : 
                                   (statusChoice == 2) ? "Delivered" : "Cancelled";

             OrderStatus status;
            if(newStatus == "DELIVERED") 
            {
                status = OrderStatus::Delivered;
            }
            restaurantDAO->updateRestaurant(restaurant);

            orderDAO->updateOrderStatus(order); // sabt dar data base
            std::cout << "Order status updated to " << newStatus << std::endl;
        } else {
            std::cout << "Order not found!" << std::endl;
        }
    }
}

void AppController::editRestaurantInfo(Restaurant* restaurant) {
    int choice;
    std::cout << "\n----- Edit Restaurant Information -----" << std::endl;
    std::cout << "Current Name: " << restaurant->getName() << std::endl;
    std::cout << "Current Category: " << restaurant->getDescription() << std::endl;
    std::cout << "---------------------------------------" << std::endl;
    std::cout << "1. Change Restaurant Name" << std::endl;
    std::cout << "2. Change Category" << std::endl;
    std::cout << "3. Back to Manager Panel" << std::endl;
    std::cout << "Selection: ";
    std::cin >> choice;

    if (choice == 1) 
    {
        std::string newName;
        std::cout << "Enter new restaurant name: ";
        std::cin.ignore(); // baray pak kardan bafer ghabli
        std::getline(std::cin, newName);
        
        restaurant->setName(newName);
        
        
        restaurantDAO->updateRestaurant(restaurant); // data base
        
        std::cout << "Success! Name updated to: " << newName << std::endl;
    } 
    else if (choice == 2) 
    {
        std::string newCategory;
        std::cout << "Enter new category (e.g., Iranian, Fast Food, Italian): ";
        std::cin.ignore();
        std::getline(std::cin, newCategory);
        
        restaurant->setDescription(newCategory);
        
        
        restaurantDAO->updateRestaurant(restaurant);//mal data base
        
        std::cout << "Success! Category updated to: " << newCategory << std::endl;
    }
    else if (choice == 3) {
        return;
    }
    else {
        std::cout << "Invalid selection" << std::endl;
    }
}


void AppController::runSystemAdminPanel() //system addmin
{
    int choice;
    while (true) {
        std::cout << "\n====================================" << std::endl;
        std::cout << "      SYSTEM ADMINISTRATOR PANEL     " << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Add New Restaurant" << std::endl;
        std::cout << "2. Activate/Deactivate Restaurants" << std::endl;
        std::cout << "3. View System Reports" << std::endl;
        std::cout << "4. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 4) break;

        switch (choice) 
        {
            case 1: addNewRestaurant(); break;
            case 2: manageRestaurantActivation(); break;
            case 3: viewSystemReports(); break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    }
}

void AppController::addNewRestaurant() //ezafe kardan restaurant addmin
{
    std::string name, category;
    std::cout << "\n--- Add New Restaurant ---" << std::endl;
    std::cout << "Enter Restaurant Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "Enter Category: ";
    std::getline(std::cin, category);

    
    Restaurant* newRes = new Restaurant(0, name, "", 30, "", category);

    
    
    addRestaurant(newRes);
    std::cout << "New Restaurant ID = " << newRes->getId() << "\n";



    std::cout << "Restaurant '" << name << "' added successfully to the system!" << std::endl;
}

void AppController::manageRestaurantActivation() {
    std::cout << "\n--- Restaurant Activation Management ---" << std::endl;
    for (size_t i = 0; i < restaurants.size(); i++) 
    {
        Restaurant* res = restaurants[i];
        std::cout << "ID: " << res->getId() 
                  << " | Name: " << res->getName() 
                  << " | Status: " << (  (res->getIsActive() ? "Active" : "Inactive"))
                  << std::endl;
    }
    int id;
    std::cout << "\nEnter Restaurant ID to toggle status (0 to back): ";
    std::cin >> id;

    if (id != 0) 
    {
    bool found = false;
        for (size_t i = 0; i < restaurants.size(); i++) 
        {
            if (restaurants[i]->getId() == id) 
            {
                // makos kardan vaziyat
                bool currentStatus = restaurants[i]->getIsActive();
                restaurants[i]->setIsActive(!currentStatus); 
                std::cout << "Status updated for " << restaurants[i]->getName() << std::endl;
                found = true;
                break; // peyda shod biya biron
            }
        }
        std::cout << "Restaurant not found!" << std::endl;
    }
}

void AppController::viewSystemReports() //gozareshat
{
    std::cout << "\n========== SYSTEM REPORT ==========" << std::endl;
    std::cout << "Total Restaurants: " << restaurants.size() << std::endl;
    
    int activeCount = 0;
    for (size_t i = 0; i < restaurants.size(); ++i)
{
        Restaurant* res = restaurants[i];
        if (res && res->getStatus())
            ++activeCount;
}
    
    std::cout << "Active Restaurants: " << activeCount << std::endl;
    std::cout << "Inactive Restaurants: " << restaurants.size() - activeCount << std::endl;
    std::cout << "===================================" << std::endl;
}


void AppController::addCustomer(Customer* c) 
{
    if (c) 
    {
        customerDAO->addCustomer(c);
    }
}

Customer* AppController::findCustomerById(int id) 
{
    return customerDAO->findCustomerById(id);
}

void AppController::addMenuItemToRestaurant(int restId, MenuItem* item) 
{
    if (item) 
    {

         menuItemDAO->addMenuItem(restId, item);
    }
}

void AppController::addOrder(Order* o) 
{
    if (o) 
    {
        orderDAO->addOrder(o);
    }
}

std::vector<Customer*> AppController::getAllCustomers() 
{
    return customerDAO->getAllCustomers();
}

std::vector<Restaurant*> AppController::getAllRestaurants() 
{
    return restaurants;
}

std::vector<MenuItem*> AppController::getAllMenuItemsForRestaurant(int restId) 
{
    return menuItemDAO->getMenuItemsByRestaurant(restId);
}

void AppController::removeMenuItemById(int id) 
{
    for (auto res : restaurants) 
    {
        res->removeMenuItem(id);
    }
    menuItemDAO->removeMenuItem(id);
}





