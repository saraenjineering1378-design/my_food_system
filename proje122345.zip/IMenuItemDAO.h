#ifndef IMENU_ITEMDAO_H
#define IMENU_ITEMDAO_H

#include <vector>
#include "MenuItem.h"

class IMenuItemDAO
{
public:

   
   virtual MenuItem* findMenuItemById(int id) = 0;
   virtual std::vector<MenuItem*> getMenuItemsByRestaurant(int restaurantId) = 0;

   virtual void removeMenuItem(int itemId) = 0;
   virtual ~IMenuItemDAO() {} 

   virtual std::vector<MenuItem*> getAllMenuItems() = 0;
   virtual void addMenuItem(int restaurantId, MenuItem* item) = 0;
};
#endif