#include <iostream>
#include <vector>
#include "SQLiteRestaurantDAO.h"
#include <sstream>



std::vector<Restaurant*> SQLiteRestaurantDAO::getAllRestaurants() const
{
    std::vector<Restaurant*> list;
    std::string sql = "SELECT * FROM Restaurants;";
    
    auto rows = dbManager.fetchAll(sql);
    
    for (size_t i = 0; i < rows.size(); i++) 
    {
    // gereftan map marbot be radif feli
    std::map<std::string, std::string>& row = rows[i];

    int id = std::stoi(row["id"]);
    std::string name = row["name"];
    std::string address = row["address"];
    std::string phone = row["phoneNumber"];
    bool active = (std::stoi(row["isActive"]) != 0);

    Restaurant* r = new Restaurant(id, name, address, 30, phone, "");
    if (!active) r->deactivate();

    list.push_back(r);
}
    return list;
}

static std::string escapeSql(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (c == '\'') out += "''";
        else out += c;
    }
    return out;
}

void SQLiteRestaurantDAO::addRestaurant(Restaurant* restaurant) 

{
    if (!restaurant) return;

    std::ostringstream sql;
    sql << "INSERT INTO Restaurants (name, address, estimatedPrepTime, phoneNumber, description, isActive) VALUES ('"
        << escapeSql(restaurant->getName()) << "', '"
        << escapeSql(restaurant->getAddress()) << "', "
        << restaurant->getEstimatedPrepTime() << ", '"
        << escapeSql(restaurant->getPhoneNumber()) << "', '"
        << escapeSql(restaurant->getDescription()) << "', "
        << (restaurant->getIsActive() ? 1 : 0)
        << ");";

    if (!dbManager.executeQuery(sql.str())) {
        std::cerr << "addRestaurant failed.\n";
        return;
    }

    int newId = dbManager.getLastInsertId();
    restaurant->setId(newId);
}


void SQLiteRestaurantDAO::updateRestaurant(Restaurant* restaurant) 
{
    // فعلاً خالی
}

void SQLiteRestaurantDAO::removeRestaurant(int id) 
{
    // فعلاً خالی
}

Restaurant* SQLiteRestaurantDAO::findRestaurantById(int id) const 
{
    return nullptr; // فعلاً هیچی پیدا نمی‌کنیم
}

