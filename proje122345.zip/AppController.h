#ifndef APP_CONTROLLER_H
#define APP_CONTROLLER_H

#include "DatabaseManager.h"
#include "IRestaurantDAO.h"
#include "ICustomerDAO.h"
#include "IMenuItemDAO.h"
#include "IOrderDAO.h"
#include "Customer.h"
#include "Restaurant.h"
#include "MenuItem.h"
#include "Order.h"
#include <vector>
#include "Enums.h"

#include "SQLiteRestaurantDAO.h"
#include "SQLiteCustomerDAO.h"
#include "SQLiteMenuItemDAO.h"
#include "SQLiteOrderDAO.h"


class AppController 
{
private:

    DatabaseManager& dbManager;
    IRestaurantDAO* restaurantDAO;
    ICustomerDAO* customerDAO;
    IMenuItemDAO* menuItemDAO;
    IOrderDAO* orderDAO;

    std::vector<Restaurant*> restaurants;
    Customer* currentCustomer; 
    int nextOrderId = 1;

    // method hay dakheli komaki
    void showAdminMenu();
    void showRestaurantOwnerMenu(Restaurant* restaurant);
    void showCustomerMenu();
    void adminAddFoodItem(Restaurant* restaurant);
    void adminRemoveItem(Restaurant* restaurant);
    void customerPlaceOrder(Restaurant* restaurant);
    void removeMenuItemById(int id);

public:
    AppController(DatabaseManager& db);
    ~AppController();

    void run(); 

    
    void addCustomer(Customer* c);
    Customer* findCustomerById(int id);
    void addMenuItemToRestaurant(int restId, MenuItem* item);
    void addOrder(Order* o);
    std::vector<Customer*> getAllCustomers();
    std::vector<Restaurant*> getAllRestaurants();
    std::vector<MenuItem*> getAllMenuItemsForRestaurant(int restId);
    void addRestaurant(Restaurant* r);

    // method hay panel modiriyat
    void runRestaurantManagerPanel(Restaurant* restaurant);
    void manageRestaurantMenu(Restaurant* restaurant);
    void viewRestaurantOrders(Restaurant* restaurant);
    void editRestaurantInfo(Restaurant* restaurant);

    void runSystemAdminPanel();
    void addNewRestaurant();
    void manageRestaurantActivation();
    void viewSystemReports();
};

#endif
