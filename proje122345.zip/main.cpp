#include <iostream>
#include <vector>
#include <string>
#include "DatabaseManager.h"
#include "DatabaseInitializer.h"
#include "SQLiteCustomerDAO.h"
#include "SQLiteRestaurantDAO.h"
#include "SQLiteMenuItemDAO.h"
#include "Customer.h"
#include "Restaurant.h"
#include "FoodItem.h"
#include "DrinkItem.h"
#include "Enums.h" // برای ItemType

using namespace std;

int main() {
    // ۱. راه‌اندازی دیتابیس (مطابق DatabaseManager شما)
    DatabaseManager dbManager("restaurant_db.sqlite");
    if (dbManager.open()) { // متد open شما پارامتر نمی‌گیره
        cout << " Database opened!" << endl;
    } else {
        return 1;
    }

    // ۲. ایجاد DAOها (استفاده از dbManager.db)
    SQLiteCustomerDAO customerDAO(dbManager);   
    SQLiteRestaurantDAO restaurantDAO(dbManager); 
    SQLiteMenuItemDAO menuDAO(dbManager);       

    cout << "\n--- Adding Data ---" << endl;

    // ۳. اصلاح سازنده Customer (CustomerId, name, Wallet)
    Customer* newCustomer = new Customer(1, "Khanom Mohandes", 500.0);
    customerDAO.addCustomer(newCustomer);
    cout << "👤 Customer added!" << endl;

    // ۴. اصلاح سازنده Restaurant (۹ تا پارامتر می‌خواد طبق ارور!)
    // ما بقیه رو فعلاً NULL یا مقدار پیش‌فرض می‌دیم تا فقط تست بشه
    Restaurant* newRes = new Restaurant(1, "Tasty Palace", "Downtown", 30, "021-8888", "10-22", true, nullptr, nullptr);
    restaurantDAO.addRestaurant(newRes);
    int resId = 1; 
    cout << "🏠 Restaurant added!" << endl;

    // ۵. اصلاح سازنده DrinkItem و متد addMenuItem
    // DrinkItem(type, id, name, desc, price, available, volume, sugar)
    DrinkItem* cola = new DrinkItem(ItemType::DRINK, 2, "Cola", "Cold", 2.0, true, 0.33, false);
    
    // در DAO شما اول ID رستوران میاد بعد آیتم: addMenuItem(resId, item)
    menuDAO.addMenuItem(resId, cola);
    cout << " Menu item added!" << endl;

    cout << "\n--- Done! ---" << endl;
    
    delete newCustomer;
    delete newRes;
    delete cola;

    return 0;
}
