#include "Restaurant.h"
#include<algorithm> //baray remove if
#include <iostream>
#include <vector>
#include <string>

#include "IMenuItemDAO.h"
#include "IOrderDAO.h"


using namespace std;

Restaurant:: Restaurant(int id, const string& name, const string& address,
           int estimatedPrepTime, const string& phone, const string& description,
           bool status, IMenuItemDAO* mDAO, IOrderDAO* oDAO)
    : id(id), name(name), address(address), estimatedPrepTime(estimatedPrepTime),
      phoneNumber(phone), description(description), isActive(status),
      menuDAO(mDAO), orderDAO(oDAO) {}

    Restaurant::~Restaurant()
{
    menuDAO = nullptr;//chon pak kardan be ohde appcontroller hast
    orderDAO = nullptr;
}


    int Restaurant::getId() const
    {
        return id;
    }
    std::string Restaurant::getName() const
    {
        return name;
    }
    std::string Restaurant::getAddress() const
    {
        return address;
    }
    bool Restaurant::getStatus () const
    {
        return isActive;
    }
    int Restaurant::getEstimatedPrepTime() const
    {
        return estimatedPrepTime;
    }
    std::string Restaurant::getPhoneNumber() const
    {
        return phoneNumber;
    }
    std::string Restaurant::getDescription() const
    { 
        return description; 
    }



    void Restaurant::setName(const string& name)
    {
        this->name = name;
    }
    void Restaurant::setAddress(const string& address)
    {
        this->address = address;
    }
    void Restaurant::setStatus(bool status)
    {
        this->isActive = status;
    }
    void Restaurant::setEstimatedPrepTime(int time)
    {
        this->estimatedPrepTime = time;
    }
    void Restaurant::setPhoneNumber(const string& phone)
    {
        this->phoneNumber = phone;
    }
    void Restaurant::setDescription(const string& description)
    {
        this->description = description; 
    }

    void Restaurant::setId(int id)//ezafe jardan id
    {
        this->id = id;
    }


    void Restaurant::removeMenuItem(int itemId)
    {
        menuDAO->removeMenuItem(itemId);
    }

    MenuItem* Restaurant::findMenuItem(int itemId) const
{
     return menuDAO->findMenuItemById(itemId);

    /*for (size_t i = 0; i < menu.size(); i++)
    {
        
        if (menu[i]->getId() == itemId)
        {
            return menu[i];
        }
    }
    return nullptr; 
    return menuDAO->findMenuItemById(itemId);*/

   
}


    void Restaurant::displayRestaurantInfo() const {
    cout << "\n======= Restaurant Details =======" << endl;
    cout << "ID: " << id << endl;
    cout << "Name: " << name << endl;
    cout << "Status: " << (isActive ? "Open " : "Closed ") << endl;
    cout << "Address: " << address << endl;
    cout << "Phone: " << phoneNumber << endl;
    cout << "Prep Time: " << estimatedPrepTime << " mins" << endl;
    cout << "Description: " << description << endl;
    cout << "==================================" << endl;
}


void Restaurant::displayMenu() const 
{
    cout << "\n--- Current Menu for " << name << " ---" << endl;
    auto items = menuDAO->getAllMenuItems();
    if (items.empty()) 
    {
        cout << "Menu is currently empty. Chef is on vacation!" << endl;
    }
    else 
    {
        for (size_t i = 0; i < items.size(); i++)
        {
            items[i]->display(); 
        }
    }
}

void Restaurant::addOrder(Order* order) 
{
   //receivedOrders.push_back(order);
    orderDAO->addOrder(order);
}
void Restaurant::displayReceivedOrders() const 
{
    /*if (receivedOrders.empty()) {
        std::cout << "No orders have been received yet." << std::endl;
        return;
    }
    
    std::cout << "\n--- List of Received Orders ---" << std::endl;
    for (size_t i = 0; i < receivedOrders.size(); i++) 
    {
        std::cout << "Order #" << (i + 1) << ":" << std::endl;
        receivedOrders[i]->displayOrderDetails();
        std::cout << "-------------------------------" << std::endl;
    }*/
    std::vector<Order*> orders = orderDAO->getAllOrders();

    if (orders.empty())
    {
        cout << "No orders have been received yet." << endl;
        return;
    }

    cout << "\n--- List of Received Orders ---" << endl;
    for (size_t i = 0; i < orders.size(); i++)
    {
        cout << "Order #" << (i + 1) << ":" << endl;
        orders[i]->displayOrderDetails();
        cout << "-------------------------------" << endl;
    }
}


Order* Restaurant::findOrderId(int orderId) const
{
    /*for (size_t i = 0; i < receivedOrders.size(); i++) {
        if (receivedOrders[i]->getOrderId() == orderId) {
            return receivedOrders[i];
        }
    }
    return nullptr;*/
    return orderDAO->findOrderById(orderId);
}


bool Restaurant::getIsActive() const 
{
     return isActive; 
}
void Restaurant::setIsActive(bool status) 
{ 
    isActive = status; 
}
void Restaurant::deactivate() 
{
    isActive = false; 
}
void Restaurant::addMenuItem(int restaurantId, MenuItem* item) 
{
    if (!item) return;

    
    menu.push_back(item);//ezafe kardan b list mahali (hafeze movaghat)

    if (menuDAO) {
        menuDAO->addMenuItem(this->id, item);
    }
}

