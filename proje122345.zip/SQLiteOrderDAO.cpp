#include "SQLiteOrderDAO.h"
#include <string>

void SQLiteOrderDAO::addOrder(Order* order) {
    // darj etelat dar jadval order
    std::string sqlOrder = "INSERT INTO Orders (customerId, restaurantId, totalPrice, status, orderDate) VALUES (" +
                           std::to_string(order->getCustomerId()) + ", " +
                           std::to_string(order->getRestaurantId()) + ", " +
                           std::to_string(order->getTotalPrice()) + ", " +
                           std::to_string(static_cast<int>(order->getStatus())) + ", " +//chon database nemifahme darhal amade sazi yani chi adad moadelash o mifrestim
                           "'2023-10-27');";
    
    dbManager.executeQuery(sqlOrder);

    // gereftan akharin id tolid shode
    auto result = dbManager.fetchAll("SELECT last_insert_rowid() as lastId;");
    int orderId = std::stoi(result[0]["lastId"]);

    // ۳. darj item hay sefaresh dar jadval OrderItems
    for (auto const& item : order->getItems()) {
        std::string sqlItems = "INSERT INTO OrderItems (orderId, menuItemId, quantity) VALUES (" +
                               std::to_string(orderId) + ", " +
                               std::to_string(item->getId()) + ", 1);"; // farz bar tedad1
        dbManager.executeQuery(sqlItems);
    }
}


std::vector<Order*> SQLiteOrderDAO::getAllOrders() 
{
    std::vector<Order*> orders;
    
    // TODO: در فازهای بعدی، کدهای SQLite برای خواندن تمام سفارش‌ها از دیتابیس اینجا قرار می‌گیرد.
    // فعلاً یک وکتور خالی برمی‌گردانیم تا پروژه بدون مشکل کامپایل شود.
    
    return orders;
}



void SQLiteOrderDAO::updateOrderStatus(Order* order) 
{
    std::string sql = "UPDATE Orders SET status = " + std::to_string(static_cast<int>(order->getStatus())) +
                      ", totalPrice = " + std::to_string(order->getTotalPrice()) +
                      " WHERE id = " + std::to_string(order->getOrderId()) + ";";
    dbManager.executeQuery(sql);
}


std::vector<Order*> SQLiteOrderDAO::getOrdersByCustomer(int customerId) {
    std::vector<Order*> orders;
    
    return orders;
}

Order* SQLiteOrderDAO::findOrderById(int id) 
{
    // فعلاً برای اینکه کامپایل بشه null برمی‌گردونیم
    return nullptr; 
}

std::vector<Order*> SQLiteOrderDAO::getOrdersByRestaurant(int restaurantId) 
{
    return std::vector<Order*>(); // یک لیست خالی برمی‌گردونیم
}


