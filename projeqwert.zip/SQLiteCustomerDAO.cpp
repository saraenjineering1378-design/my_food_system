
#include "SQLiteCustomerDAO.h"
#include "Customer.h"        
#include "DatabaseManager.h"  
#include <string>             



void SQLiteCustomerDAO::addCustomer(Customer* customer)
{
    std::string sql =
        "INSERT INTO Customers (name, walletBalance) VALUES ('" +
        customer->getName() + "', " + std::to_string(customer->getWallet()) + ");";

    if (!dbManager.executeQuery(sql)) 
    {
        std::cerr << "addCustomer failed\n";
        return;
    }

    int newId = dbManager.getLastInsertId();
    customer->setCustomerId(newId);
}



std::vector<Customer*> SQLiteCustomerDAO::getAllCustomers() const 
{
    std::vector<Customer*> list;
    std::string sql = "SELECT * FROM Customers;";

    auto rows = dbManager.fetchAll(sql);
        for (const auto& row : rows) 
        {
        Customer* c = new Customer(
            std::stoi(row.at("id")),              
            row.at("name"),                      
            std::stod(row.at("walletBalance"))   
        );
        list.push_back(c);
        }
    return list;
}


Customer* SQLiteCustomerDAO::findCustomerById(int id) const 
{
    std::string sql = "SELECT * FROM Customers WHERE id = " + std::to_string(id) + ";";
    auto rows = dbManager.fetchAll(sql);
    
    if (rows.empty()) return nullptr;
    
    auto& row = rows[0];
    return new Customer(std::stoi(row.at("id")), row.at("name"), std::stod(row.at("walletBalance")));
}

