#include "AppController.h"
#include "FoodItem.h"
#include <iostream>
#include "DatabaseInitializer.h"
#include <limits>
#include "Customer.h" 




AppController::AppController(DatabaseManager& db) : dbManager(db), currentCustomer(nullptr) 
{
    // age jadval ha vojod nadaran misazim
    DatabaseInitializer::initialize(dbManager);

    // jay gozin kardan sqlite b jay memory
    restaurantDAO = new SQLiteRestaurantDAO(dbManager);
    customerDAO = new SQLiteCustomerDAO(dbManager);
    menuItemDAO = new SQLiteMenuItemDAO(dbManager);
    orderDAO = new SQLiteOrderDAO(dbManager, menuItemDAO);

    
}


void AppController::addRestaurant(Restaurant* r) //ezafe kardan resturan
{
    if (!r) return;
    restaurantDAO->addRestaurant(r);   //ham insert ham setid
    restaurants.push_back(r);          // va bad ham toy list hafeze negah midarim
}

void AppController::run()
{
    int role = 0;
    while (role != 4)
    {
        std::cout << "\n=== Food Ordering System ===\n";
        std::cout << "1. Admin\n2. Restaurant Owner\n3. Customer\n4. Exit\nSelect an option: ";
        std::cin >> role;

        switch (role)
        {
        case 1:
            showAdminMenu();
            break;
        case 2:
            for(size_t i=0; i<restaurants.size(); ++i) std::cout << i+1 << ". " << restaurants[i]->getName() << "\n";
            int idx; std::cin >> idx;
            if(idx > 0 && idx <= (int)restaurants.size()) showRestaurantOwnerMenu(restaurants[idx-1]);
            break;
        case 3:
            showCustomerMenu();
            break;
        case 4:
            std::cout << "Exiting system...\n";
            break;
        default:
            std::cout << "Invalid choice!\n";
            break;
        }
    }
}

//Admin Menu 
void AppController::showAdminMenu()
{
    int choice = 0;
    while (choice != 3)
    {
        std::cout << "\n--- Admin Panel ---\n";
        std::cout << "1. Manage Restaurants (Activate/Deactivate)\n2. View General Report\n3. Back\nSelect: ";
        std::cin >> choice;

        if (choice == 1)
            std::cout << "Restaurant status updated.\n";
        else if (choice == 2)
            std::cout << "Report: Total Orders: " << (nextOrderId - 1) << " | Total Sales: Calculating...\n";
    }
}

// Restaurant Owner Menu 
void AppController::showRestaurantOwnerMenu(Restaurant* restaurant) 
{
    int choice = 0;
    while (choice != 4) 
    {
        std::cout << "\n--- Restaurant Manager Panel ---\n";
        std::cout << "1. Manage Menu\n2. View Received Orders\n3. Update Order Status\n4. Back\nSelect: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
            { 
                std::cout << "1. Add Item\n2. Remove Item\n3. Update Item\nSelect: ";
                int sub; 
                std::cin >> sub;

                if (sub == 1) {
                    adminAddFoodItem(restaurant); 
                } else if (sub == 2) {
                    adminRemoveItem(restaurant);
                } else if (sub == 3) {
                    adminUpdateItem(restaurant);
                } else {
                std::cout << "Invalid choice!\n";
            }

            }
            case 2: 
                std::cout << "\n--- Received Orders ---\n";
                restaurant->displayReceivedOrders();
                break;
            case 3: // Update Order Status
            {
                restaurant->displayReceivedOrders(); // aval sefaresh haro bebine
                std::cout << "Enter order ID to update: ";
                int oId; std::cin >> oId;
                Order* ord = restaurant->findOrderId(oId); 
                if(ord) 
                {
                    std::cout << "1. Preparing, 2. Delivered. Select: ";
                    int st; std::cin >> st;
                    if(st == 1) ord->updateStatus(OrderStatus::Preparing);
                    else if(st == 2) ord->updateStatus(OrderStatus::Delivered);
                    std::cout << "Status updated!\n";
                }
                 else
                {
                    std::cout << "Order not found!\n";
                }
                
    
                break;
            
            }
            case 4: break;
        }
    }
}


// Customer Menu
void AppController::showCustomerMenu()
{ 
    if (currentCustomer == nullptr) //baray in ke age karbari nabod ghati nakone
    {
        std::cout << "\n Wait a minute! You need to login first to access the Customer Panel!\n";
        return;//khoroj baray jologiri kardan az ghati kardan barname 
    }

    if (restaurants.empty()) 
    {
        std::cout << "Sorry! There are no restaurants available." << std::endl;
        return;
    }

    std::cout << "\n--- Select a Restaurant ---\n"; // baray entekhab restaurant morednazar
    for (size_t i = 0; i < restaurants.size(); i++) 
    {
        std::cout << i + 1 << ". " << restaurants[i]->getName() << "\n"
        << " (address " << restaurants[i]->getAddress() << ")" << std::endl;
    }

    std::cout << "0. Back to Main Menu\n";

    int restChoice;
    std::cout << "Select option: ";
    std::cin >> restChoice;

    if (restChoice == 0) return; // bargasht b menu asli
    if (restChoice < 1 || restChoice > restaurants.size()) // etebar sanji entekhab karbar
    {
        std::cout << "Invalid choice!\n";
        return;
    }

    Restaurant* selected= restaurants[restChoice - 1];//resturan entekhab shode ro bardar

    int choice = 0;
    while (choice != 5) 
    {
        std::cout << "\n--- Customer Panel ---\n";
        std::cout << "Your Current Balance: $" << currentCustomer->getWallet() << "\n";//namayesh mojodi kifpol
        std::cout << "1. View Restaurant Menu\n";
        std::cout << "2. Place Order\n";
        std::cout << "3. View Order History\n";
        std::cout << "4. Charge Wallet\n"; 
        std::cout << "5. Back to Main Menu\n";
        std::cout << "Select option: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
                if (!selected->getIsActive()) 
                {
                    std::cout << "Sorry! The restaurant is currently closed.\n";
                } else 
                {
                    selected->displayMenu();
                }
                break;
            
            case 2:
                if (!selected->getIsActive()) 
                {
                    std::cout << "Cannot place order! The restaurant is closed. (Chef is sleeping!)\n";
                } else 
                {
                    std::cout << "\n--- Ordering Menu ---\n";
                    selected->displayMenu(); // namayesh menu baray entekhab rahattar

                    bool ordering = true;
                    int cartChoice = -1;

                    while (ordering) {
                        std::cout << "\n--- Cart Menu ---\n";
                        std::cout << "Live Total: $" << currentCustomer->getTotal() << "\n"; 
                        std::cout << "1. Add Item (by ID)\n";
                        std::cout << "2. Remove Item (by ID)\n";
                        std::cout << "3. Finalize & Checkout\n";
                        std::cout << "0. Cancel Order\n";
                        std::cout << "Choose an action: ";
                        std::cin >> cartChoice;

                        if (cartChoice == 1) {
                            int foodId;
                            std::cout << "Enter Food ID to ADD: ";
                            std::cin >> foodId;
                            
                            MenuItem* item = nullptr; 
                            
                            
                            //item = new FoodItem(foodId, "Test Food", "Delicious!", 10.5, true, 15, false);
                            
                            
                            item = selected->findMenuItem(foodId);

                            if (item) {
                                int qty;
                                std::cout << "How many? ";
                                std::cin >> qty;
                                for(int i=0; i < qty; ++i) {
                                    currentCustomer->addToCart(item);
                                }
                                std::cout << " " << qty << " Item(s) added to cart! Yummy! \n";
                            } else {
                                std::cout << " Invalid Food ID!\n";
                            }
                        }
                        else if (cartChoice == 2) {
                            int foodId;
                            std::cout << "Enter Food ID to REMOVE: ";
                            std::cin >> foodId;
                            
                            
                            //farakhani method hazf az sabad kharid
                            currentCustomer->removeFromCart(foodId);
                            std::cout << " Item removed (if existed).\n";
                        }
                        else if (cartChoice == 3) {
                            ordering = false; // khoroj az halghe va raftan b bakhsh pardakht
                        }
                        else if (cartChoice == 0) {
                            currentCustomer->clearCart(); //khali kardan darsorat enseraf
                            std::cout << "Order cancelled!\n";
                            break; // khoroj kamel az halghe
                        }
                        else {
                            std::cout << "Invalid choice! Try again.\n";
                        }
                    }

                    // age karbar 0 zad  va monsaref shod dige nare baray pardakht
                    if (cartChoice == 0) {
                        break; 
                    }

                    double totalAmount = currentCustomer->getTotal();
                    if (totalAmount > 0) {
                        std::cout << "\n Total amount to pay: $" << totalAmount << "\n";
                        
                        // barrasi mojodi kif pol
                        if (currentCustomer->getWallet() >= totalAmount) {
                            
                            currentCustomer->addFunds(-totalAmount); 
                            std::cout << " Payment successful! Your order has been placed. Bon appetit!\n";
                            
                            currentCustomer->clearCart(); //khali kardan sabad kharid bad az movafaghiyat
                        } else {
                            std::cout << "💸 Not enough funds! Please charge your wallet first.\n";
                            currentCustomer->clearCart(); //khali kardan sabad b khater adam mojodi
                        }
                    } else {
                        std::cout << "Your cart is empty. No order placed.\n";
                    }
                }
                break;
            
            case 3:
                currentCustomer->displayOrderHistory();
                break;
            
            case 4: 
            {
                // baray sharj kof pol
                double amount;
                std::cout << "Enter the amount to add to your wallet: ";
                std::cin >> amount;
                if (amount > 0) {
                    currentCustomer->addFunds(amount);
                    std::cout << " Wallet charged successfully! Your new balance: $" << currentCustomer->getWallet() << "\n";
                } else {
                    std::cout << "Invalid amount!\n";
                }
                break;
            }
            
            case 5:
            {
                std::cout << "Returning to main menu...\n";
                break;
            }
            
            default:
            {
                std::cout << "Invalid choice! Please select 1-5.\n";
                break;
            }
        }
    }
}



void AppController::runRestaurantManagerPanel(Restaurant* restaurant) //safhe modir resturan
{
    int choice;
    while (true) 
    {
        std::cout << "\n==================================" << std::endl;
        std::cout << "   MANAGER PANEL: " << restaurant->getName() << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Edit Restaurant Info" << std::endl;
        std::cout << "2. Manage Menu (Add/Edit/Remove Items)" << std::endl;
        std::cout << "3. View & Process Incoming Orders" << std::endl;
        std::cout << "4. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 4) break;

        switch (choice) 
        {
            case 1: editRestaurantInfo(restaurant); break;
            case 2: manageRestaurantMenu(restaurant); break;
            case 3: viewRestaurantOrders(restaurant); break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    }
} 

void AppController::manageRestaurantMenu(Restaurant* restaurant) 
{
    int choice;
    std::cout << "\n--- Menu Management ---" << std::endl;
    std::cout << "1. Add New Food" << std::endl;
    std::cout << "2. Remove Item" << std::endl;
    std::cout << "3. Back" << std::endl;
    std::cin >> choice;

    if (choice == 1) 
    {
        std::string name;
        double price;
        std::cout << "Enter Food Name: ";
        std::cin.ignore();
        std::getline(std::cin, name);
        std::cout << "Enter Price: ";
        std::cin >> price;

        MenuItem* newItem = new FoodItem(0, name, "No description", price, true, 20, false);

        
        menuItemDAO->addMenuItem(restaurant->getId(),newItem);//vasl be data base


        
           bool success = menuItemDAO->addMenuItem(restaurant->getId(),newItem);
   if (success) {
       std::cout << "Yummy! '" << name << "' added to the menu! 🍕\n";
   } else {
       std::cout << "Oops! Failed to add item. Maybe the Restaurant ID (" << restaurant->getId() << ") is wrong! \n";
   }

}
    else if (choice == 2) {
        restaurant->displayMenu();
        int id;
        std::cout << "Enter Item ID to remove: ";
        std::cin >> id;
        restaurant->removeMenuItem(id);
        menuItemDAO->removeMenuItem(id); //vasl b data base
    }
}


void AppController::viewRestaurantOrders(Restaurant* restaurant) 
{
    while (true) {
        // First, display all orders for the restaurant
        std::cout << "\n--- Orders for " << restaurant->getName() << " ---" << std::endl;
        bool hasOrders = false;
        for (Order* order : orderDAO->getAllOrders()) {
            if (order->getRestaurantId() == restaurant->getId()) {
                hasOrders = true;
                std::cout << "Order ID: " << order->getOrderId()
                     << " | Customer ID: " << order->getCustomerId()
                     << " | Total: $" << order->getTotalPrice()
                     << " | Status: " << static_cast<int>(order->getStatus()) << std::endl;

                // Optional: Display items in the order
                std::cout << "  Items:" << std::endl;
                for(const auto& item : order->getItems()){
                    std::cout << "    - " << item->getName() << " ($" << item->getBasePrice() << ")" << std::endl;
                }
            }
        }

        if (!hasOrders) {
            std::cout << "No orders found for this restaurant." << std::endl;
        }

        std::cout << "\n------------------------------------" << std::endl;
        std::cout << "Enter Order ID to update status (or 0 to return to menu): ";
        int orderId;
        std::cin >> orderId;

        // Input validation
        if (std::cin.fail()) {
            std::cout << "\n[!] Invalid input. Please enter a number." << std::endl;
            std::cin.clear(); // Clear error flags
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard bad input
            continue; // Go to the next loop iteration
        }


        if (orderId == 0) {
            std::cout << "Returning to the manager menu..." << std::endl;
            break;
        }

        Order* order = orderDAO->findOrderById(orderId);


        if (order != nullptr && order->getRestaurantId() == restaurant->getId()) 
        {
            std::cout << "\nSelect new status for Order ID " << orderId << ":" << std::endl;
            std::cout << "1. Preparing" << std::endl;
            std::cout << "2. Delivering" << std::endl;
            std::cout << "3. Completed" << std::endl;
            std::cout << "4. Canceled" << std::endl;
            std::cout << "Enter your choice: ";
            int statusChoice;
            std::cin >> statusChoice;

            if (std::cin.fail()) {
                std::cout << "\n[!] Invalid input. Please enter a number." << std::endl;
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }

            OrderStatus newStatus;
            bool validChoice = true;
            switch (statusChoice) {
                case 1: newStatus = OrderStatus::Preparing; break;
                case 2: newStatus = OrderStatus::Delivered; break; 
                case 3: newStatus = OrderStatus::Delivered; break; 
                case 4: newStatus = OrderStatus::Cancelled; break;
                default:
                    validChoice = false;
                    std::cout << "\n[X] Invalid choice! Status remains unchanged." << std::endl;
                    break;
            }

            if(validChoice) {
                order->setStatus(newStatus);
                orderDAO->updateOrderStatus(order);
                std::cout << "\n[>>] Success! Order status has been updated." << std::endl;
            }

        } else {
            std::cout << "\n[!] Order with this ID not found or does not belong to your restaurant." << std::endl;
        }
        std::cout << "\nPress Enter to continue...";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the leftover newline from previous cin
        std::cin.get(); // Wait for user to press Enter
    }
}



void AppController::editRestaurantInfo(Restaurant* restaurant) {
    int choice;
    std::cout << "\n----- Edit Restaurant Information -----" << std::endl;
    std::cout << "Current Name: " << restaurant->getName() << std::endl;
    std::cout << "Current Category: " << restaurant->getDescription() << std::endl;
    std::cout << "---------------------------------------" << std::endl;
    std::cout << "1. Change Restaurant Name" << std::endl;
    std::cout << "2. Change Category" << std::endl;
    std::cout << "3. Back to Manager Panel" << std::endl;
    std::cout << "Selection: ";
    std::cin >> choice;

    if (choice == 1) 
    {
        std::string newName;
        std::cout << "Enter new restaurant name: ";
        std::cin.ignore(); // baray pak kardan bafer ghabli
        std::getline(std::cin, newName);
        
        restaurant->setName(newName);
        
        
        restaurantDAO->updateRestaurant(restaurant); // data base
        
        std::cout << "Success! Name updated to: " << newName << std::endl;
    } 
    else if (choice == 2) 
    {
        std::string newCategory;
        std::cout << "Enter new category (e.g., Iranian, Fast Food, Italian): ";
        std::cin.ignore();
        std::getline(std::cin, newCategory);
        
        restaurant->setDescription(newCategory);
        
        
        restaurantDAO->updateRestaurant(restaurant);//mal data base
        
        std::cout << "Success! Category updated to: " << newCategory << std::endl;
    }
    else if (choice == 3) {
        return;
    }
    else {
        std::cout << "Invalid selection" << std::endl;
    }
}


void AppController::runSystemAdminPanel() //system addmin
{
    int choice;
    while (true) {
        std::cout << "\n====================================" << std::endl;
        std::cout << "      SYSTEM ADMINISTRATOR PANEL     " << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Add New Restaurant" << std::endl;
        std::cout << "2. Activate/Deactivate Restaurants" << std::endl;
        std::cout << "3. View System Reports" << std::endl;
        std::cout << "4. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 4) break;

        switch (choice) 
        {
            case 1: addNewRestaurant(); break;
            case 2: manageRestaurantActivation(); break;
            case 3: viewSystemReports(); break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    }
}

void AppController::addNewRestaurant() // ezafe kardan restaurant admin
{
    std::string name, category, address, phone, description;
    
    std::cout << "\n--- Add New Restaurant ---" << std::endl;
    std::cout << "Enter Restaurant Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    
    std::cout << "Enter Category: ";
    std::getline(std::cin, category);
    
    std::cout << "Enter Address: ";
    std::getline(std::cin, address);
    
    std::cout << "Enter Phone: ";
    std::getline(std::cin, phone);
    
    std::cout << "Enter Description: ";
    std::getline(std::cin, description);

    // sakht restaurant hay jadid ba parameter hay lazem

    Restaurant* newRes = new Restaurant(0, name, address, 30, phone, description);
    

    restaurants.push_back(newRes);
    restaurantDAO->addRestaurant(newRes); // sabt dar database

    std::cout << "✅ Restaurant '" << name << "' added successfully to the system!" << std::endl;
}

void AppController::manageRestaurantActivation() {
    std::cout << "\n--- Restaurant Activation Management ---" << std::endl;
    for (size_t i = 0; i < restaurants.size(); i++) 
    {
        Restaurant* res = restaurants[i];
        std::cout << "ID: " << res->getId() 
                  << " | Name: " << res->getName() 
                  << " | Status: " << (  (res->getIsActive() ? "Active" : "Inactive"))
                  << std::endl;
    }
    int id;
    std::cout << "\nEnter Restaurant ID to toggle status (0 to back): ";
    std::cin >> id;

    if (id != 0) 
    {
    bool found = false;
        for (size_t i = 0; i < restaurants.size(); i++) 
        {
            if (restaurants[i]->getId() == id) 
            {
                // makos kardan vaziyat
                bool currentStatus = restaurants[i]->getIsActive();
                restaurants[i]->setIsActive(!currentStatus); 
                std::cout << "Status updated for " << restaurants[i]->getName() << std::endl;
                found = true;
                break; // peyda shod biya biron
            }
        }
        std::cout << "Restaurant not found!" << std::endl;
    }
}

void AppController::viewSystemReports() //gozareshat
{
    std::cout << "\n========== SYSTEM REPORT ==========" << std::endl;
    std::cout << "Total Restaurants: " << restaurants.size() << std::endl;
    
    int activeCount = 0;
    for (size_t i = 0; i < restaurants.size(); ++i)
{
        Restaurant* res = restaurants[i];
        if (res && res->getIsActive())
            ++activeCount;
}
    
    std::cout << "Active Restaurants: " << activeCount << std::endl;
    std::cout << "Inactive Restaurants: " << restaurants.size() - activeCount << std::endl;
    std::cout << "===================================" << std::endl;
}


void AppController::addCustomer(Customer* c) 
{
    if (c) 
    {
        customerDAO->addCustomer(c);
    }
}

Customer* AppController::findCustomerById(int id) 
{
    return customerDAO->findCustomerById(id);
}

void AppController::addMenuItemToRestaurant(int restId, MenuItem* item) 
{
    if (item) 
    {

         menuItemDAO->addMenuItem(restId, item);
    }
}

void AppController::addOrder(Order* o) 
{
    if (o) 
    {
        orderDAO->addOrder(o);
    }
}

std::vector<Customer*> AppController::getAllCustomers() 
{
    return customerDAO->getAllCustomers();
}

std::vector<Restaurant*> AppController::getAllRestaurants() 
{
    return restaurants;
}

std::vector<MenuItem*> AppController::getAllMenuItemsForRestaurant(int restId) 
{
    return menuItemDAO->getMenuItemsByRestaurant(restId);
}

void AppController::removeMenuItemById(int id) 
{
    for (auto res : restaurants) 
    {
        res->removeMenuItem(id);
    }
    menuItemDAO->removeMenuItem(id);
}

void AppController::adminUpdateItem(Restaurant* restaurant) {
    int id;
    std::cout << "Enter Item ID to update: ";
    std::cin >> id;

    // migardim bebinim hamchin itemi darim yana
    MenuItem* item = restaurant->findMenuItem(id);
    if (!item) {
        std::cerr << "Error: Item not found!\n";
        return;
    }

    // gheymat jadid ro mogirim
    double newPrice;
    std::cout << "Current Price is: " << item->getBasePrice() << "\n";
    std::cout << "Enter new price: ";
    std::cin >> newPrice;

    // ghemat ro toy ubject updte mikonim
    item->setBasePrice(newPrice);

    // mifrestimesh to database zakhire beshe
    menuItemDAO->updateMenuItem(item);
    
    std::cout << "Item successfully updated! Boss will be happy.\n";
}
void AppController::adminAddFoodItem(Restaurant* restaurant)
{
    std::cout << "\n--- Admin: Add Food Item ---" << std::endl;
    //list  resturan haro neshon bedim addmin entekhab bokone
    if (restaurants.empty()) {
        std::cout << "No restaurants available! Please add a restaurant first." << std::endl;
        return;
    }
    
    
    std::cout << "🛠 This feature is under construction. Coming soon!" << std::endl;
}

void AppController::adminRemoveItem(Restaurant* restaurant)
{
    std::cout << "\n--- Admin: Remove Item ---" << std::endl;
   
    std::cout << "🛠 This feature is under construction. Coming soon!" << std::endl;
}


AppController::~AppController()
{
    // azad sazi hafede resturan ha
    for (size_t i = 0; i < restaurants.size(); ++i) {
        delete restaurants[i];
    }
    restaurants.clear();
    
}


void AppController::customerLoginMenu() 
{
    bool isLoggedIn = false;
    while (!isLoggedIn) {
        std::cout << "\n=========================================\n";
        std::cout << "      🍔 Welcome to Customer Portal 🍔      \n";
        std::cout << "=========================================\n";
        std::cout << "1. Login (ورود)\n";
        std::cout << "2. Sign Up (ثبت نام)\n";
        std::cout << "0. Back to Main Menu (بازگشت)\n";
        std::cout << "Enter your choice: ";
        
        int choice;
        std::cin >> choice;
        
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "\n❌ Voroodi namotabar! Lotfan faghat adad vared konid.\n";
            continue;
        }

        if (choice == 1) {
            isLoggedIn = customerLogin();
            if (isLoggedIn) {
                std::cout << "\n🎉 Login movafaghiyat amiz bood! Khosh amadid! 🎉\n";
                showCustomerMenu();
                
                //bad khoroj az menu ,hafeze ro movaghat pak mikonim
                delete currentCustomer; 
                currentCustomer = nullptr;
                isLoggedIn = false; // baray in ke 2 bare ba yek account dige login kone
        } 
        else if (choice == 2) {
            if (customerSignup()) {
                std::cout << "\n✅ Sabt nam anjam shod! Hata mitavanid Login konid.\n";
            }
        } 
        else if (choice == 0) {
            break;
        } 
        else {
            std::cout << "\n❌ Entekhab eshtebah ast! Dastet khord be keyboard? Dobare emtehan kon!\n";
        }
    }
}
}

bool AppController::customerSignup() 
{
    std::string name;
    
    std::cout << "\n--- 📝 Customer Sign Up (Sabt Nam) ---\n";
    std::cout << "Enter Name (Nam-e shoma): ";
    
    // pak kardan bafer baray jologiri az paresh
    std::cin.ignore(256, '\n');
    std::getline(std::cin, name);
    //sakht moshtari jadid
    Customer* newCustomer = new Customer(0, name, 0.0f); 
    
    // zakhire dar database
    customerDAO->addCustomer(newCustomer);
    
    std::cout << "\n✅ Moshtari [" << name << "] ba movafaghiyat dar Database sabt shod!\n";
    
    // pak kardan hafeze chon database etelaat ro zakhire mikone
    delete newCustomer;
    
    return true; 
}

bool AppController::customerLogin() 
{
    int inputId;
    std::string inputName;
    
    std::cout << "\n--- 🔐 Customer Login (Vorood) ---\n";
    std::cout << "Enter Customer ID (Shenase): ";
    std::cin >> inputId;
    
    if (std::cin.fail()) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "\n❌ Shenase bayad adad bashe!\n";
        return false;
    }

    std::cout << "Enter Name (Nam-e shoma): ";
    std::cin.ignore(256, '\n'); // pak kardan bafer
    std::getline(std::cin, inputName);

    // gereftan tamam moshtari ha az database
    auto allCustomers = customerDAO->getAllCustomers();
    
    for (auto* c : allCustomers) {
        //barrasi id va name
        if (c->getCustomerId() == inputId && c->getName() == inputName) 
        { 
            // age peyda shod copy mikonim to moshtari feli barname
            currentCustomer = new Customer(*c); 
            
            // hafeze hay takhsis dadeshode ro pak mikonim ke memory leak nadashte bashim
            for (auto* customer : allCustomers) {
                delete customer;
            }
            return true;
        }
    }

    std::cout << "\n❌ Khata: Shenase ya Nam eshtebah ast! Kasi ba in moshakhasat peyda nashod 🕵️‍♂️\n";
    
    // dar sorat shekast bazham bayad hafeze ro azad konim
    for (auto* c : allCustomers) {
        delete c;
    }
    return false;
}
