#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <vector>
#include <string>
#include  "Order.h"
#include "MenuItem.h"

class Customer
{
private:

    int CustomerID;
    std::string name;
    //std::string email;    
    //std::string password;
    double Wallet;
    std::vector<Order*> OrderHistory;
    std::vector<MenuItem*> cart;//sabad kharid moshtari

public:

    Customer(int CustomerId, std::string name, double Wallet);

    ~Customer();

    //getterha
    int getCustomerId() const;
    std::string getName() const;
    double getWallet() const;


    void setName(std::string Name); // chon b motghayer private, mostaghim dastresi nadarim baray taviz nam az set kardan mirim
    void setCustomerId(int id);

    
    //baray moshtariha
    void addFunds(double amount);   //sharj hesab        
    bool payForOrder(double amount); //pardakht sefaresh
    void addOrderToHistory(Order* order);  //ezafe kardan be history 
    void displayOrderHistory() const;     //namayesh list sefareshat

    void addToCart(MenuItem* item);//ghesmat sabad kharid
    double getTotal() const;
    void clearCart();

    void removeFromCart(int foodId);

    //std::string getEmail() const;
    //std::string getPassword() const;

};
#endif