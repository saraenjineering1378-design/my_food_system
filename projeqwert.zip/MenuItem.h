#ifndef MENU_ITEM_H
#define MENU_ITEM_H

#include <string>
#include "Enums.h"




class MenuItem //base class ke baghiye az on erth mibaran
{
private:

    int id;
    std::string name;
    std::string description;
    double basePrice;
    bool isAvailable;

    ItemType type;

    static int typeToInt(ItemType type); // adad kardan food drink dessert
    static ItemType intToType(int val); // tabdil adad b food dessert drink


public:

    MenuItem(ItemType t,int id, const std::string& name, 
            const std::string& description, double basePrice,
            bool isAvailable);

    virtual ~MenuItem() = default;

    ItemType getType() const;


    //getterha  chon dade ha private hastand dastresi az tarigh geteer ha anjam mishavad
    int getId() const;
    std::string getName() const;
    std::string getDescription() const;
    double getBasePrice() const;
    bool getIsAvailable() const;

    //setterha
    void setName(const std::string& name);
    void setDescription(const std::string& description);
    void setBasePrice(double price);
    void setIsAvailable(bool status);

    virtual void display() const ; //chandrikhti

};
#endif