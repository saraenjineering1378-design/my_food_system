#include "DatabaseManager.h"
#include "DatabaseInitializer.h"
#include "AppController.h"
#include "Restaurant.h"
#include <iostream>
#include <vector>
#include <cstdlib> // برای تابع system
#include <conio.h> // 🔹 اضافه شده برای خواندن پسورد به صورت ستاره‌ای

using namespace std;

// ==========================================
//                 MAIN
// ==========================================
int main() 
{
    // جادوی فارسی‌نویسی در ویندوز (UTF-8) 🪄
    system("chcp 65001 > nul");

    // اتصال به دیتابیس (خدا کنه منفجر نشه! 💥)
    DatabaseManager db("food_system.db");

    if (!db.open()) {
        cerr << "Error: Could not open database connection. Did you break it?! 💥" << endl;
        return 1;
    }

    // راه‌اندازی و ساخت جداول در صورت نیاز
    DatabaseInitializer::initialize(db);
    
    // ساخت قلب تپنده‌ی برنامه‌ی ما ❤️
    AppController appController(db);

    int mainChoice;
    do {
        cout << "\n=================================\n";
        cout << "   Welcome to the Food System! 🍽️\n";
        cout << "=================================\n";
        cout << "1. Customer Portal 🍔\n";
        cout << "2. Manager Portal 👨‍🍳\n";
        cout << "3. Admin Portal 👑\n";
        cout << "0. Exit 🏃‍♂️\n";
        cout << "Enter your role: ";
        
        // جلوگیری از کرش کردن برنامه اگر کاربر به جای عدد، حرف وارد کرد! 🛡️
        if (!(cin >> mainChoice)) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Numbers only, my friend! We don't speak alphabet here. 🧐\n";
            continue;
        }

        switch (mainChoice) 
        {
            case 1: 
                // واگذاری تمام کارهای مشتری به متد مخصوص خودش توی کنترلر
                appController.customerLoginMenu(); 
                break;
                
            case 2: 
                appController.managerLoginMenu(); 
                break;
                
            case 3: // 🔐 بخش اصلاح شده: سیستم تایید هویت و پسورد ادمین
                {
                    string password = "";
                    char ch;
                    cout << "\n--- 🔐 Admin Security Check ---" << endl;
                    cout << "Enter Admin Password: ";
                    
                    // حلقه دریافت کاراکترها به صورت مخفی و نمایش ستاره
                    while (true) {
                        ch = _getch(); // دریافت کلید بدون چاپ روی صفحه
                        
                        if (ch == 13) { // دکمه Enter
                            break;
                        }
                        else if (ch == 8) { // دکمه Backspace برای پاک کردن اشتباهات
                            if (!password.empty()) {
                                password.pop_back();
                                cout << "\b \b"; // پاک کردن ستاره از ترمینال
                            }
                        } 
                        else if (ch >= 32 && ch <= 126) { // کاراکترهای مجاز و استاندارد کیبورد
                            password.push_back(ch);
                            cout << "*"; // چاپ ستاره به جای حروف اصلی
                        }
                    }

                    // 🔹 رمز ورود در حال حاضر admin123 است (می‌توانی تغییرش دهی)
                    if (password == "admin123") 
                    {
                        cout << "\n\n✅ Access Granted! Welcome Admin.\n";
                        appController.runSystemAdminPanel(); // ورود به پنل ادمین کل سیستم
                    } 
                    else 
                    {
                        cout << "\n\n❌ Access Denied! Wrong password. Don't try to hack us! 🧐\n";
                    }
                }
                break;
                
            case 0: 
                cout << "Goodbye! Have a delicious day! 👋\n"; 
                break;
                
            default: 
                cout << "Invalid choice! Try again, my friend. 🧐\n";
        } 
        
    } while (mainChoice != 0);
    
    return 0;
}

