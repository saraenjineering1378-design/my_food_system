#include "AppController.h"
#include <iostream>
#include "DatabaseInitializer.h"
#include <limits>
#include "Customer.h"
#include "FoodItem.h"
#include "DrinkItem.h"
#include "DessertItem.h"
#include "Enums.h"
#include "MenuItem.h"



AppController::AppController(DatabaseManager& db) : dbManager(db), currentCustomer(nullptr) 
{
    // age jadval ha vojod nadaran misazim
    DatabaseInitializer::initialize(dbManager);

    // jay gozin kardan sqlite b jay memory
    restaurantDAO = new SQLiteRestaurantDAO(dbManager);
    customerDAO = new SQLiteCustomerDAO(dbManager);
    menuItemDAO = new SQLiteMenuItemDAO(dbManager);
    orderDAO = new SQLiteOrderDAO(dbManager, menuItemDAO);

    
}



void AppController::addRestaurant(Restaurant* r) //ezafe kardan resturan
{
    if (!r) return;
    restaurantDAO->addRestaurant(r);   //ham insert ham setid
    restaurants.push_back(r);          // va bad ham toy list hafeze negah midarim
}

void AppController::run()
{
    int role = 0;
    while (role != 4)
    {
        std::cout << "\n=== Food Ordering System ===\n";
        std::cout << "1. Admin\n2. Restaurant Owner\n3. Customer\n4. Exit\nSelect an option: ";
        std::cin >> role;

        switch (role)
        {
        case 1:
            showAdminMenu();
            break;
        case 2:
            for(size_t i=0; i<restaurants.size(); ++i) std::cout << i+1 << ". " << restaurants[i]->getName() << "\n";
            int idx; std::cin >> idx;
            if(idx > 0 && idx <= (int)restaurants.size()) runRestaurantManagerPanel(restaurants[idx-1]);
            break;
        case 3:
            customerLoginMenu();
            break;
        case 4:
            std::cout << "Exiting system...\n";
            break;
        default:
            std::cout << "Invalid choice!\n";
            break;
        }
    }
}

//Admin Menu 
void AppController::showAdminMenu()
{
    int choice = 0;
    while (choice != 3)
    {
        std::cout << "\n--- Admin Panel ---\n";
        std::cout << "1. Manage Restaurants (Activate/Deactivate)\n2. View General Report\n3. Back\nSelect: ";
        std::cin >> choice;

        if (choice == 1)
            std::cout << "Restaurant status updated.\n";
        else if (choice == 2)
            std::cout << "Report: Total Orders: " << (nextOrderId - 1) << " | Total Sales: Calculating...\n";
    }
}

// Restaurant Owner Menu 
void AppController::manageRestaurantMenu(Restaurant* restaurant) 
{
    if (!restaurant) return;

    int choice;
    while (true) 
    {
        std::cout << "\n==================================" << std::endl;
        std::cout << "   MANAGE MENU: " << restaurant->getName() << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Add Food Item" << std::endl;
        std::cout << "2. Remove Food Item" << std::endl;
        std::cout << "3. Update Food Item" << std::endl;
        std::cout << "4. Back to Manager Panel" << std::endl;
        std::cout << "Selection: ";
        
        if (!(std::cin >> choice)) {
            std::cout << "❌ Invalid choice! Please enter a number." << std::endl;
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }
        std::cin.ignore(10000, '\n');

        if (choice == 4) break;

        switch (choice) 
        {
            case 1: managerAddFoodItem(restaurant); break;
            case 2: managerRemoveItem(restaurant); break;
            case 3: managerUpdateItem(restaurant); break;
            default: std::cout << "❌ Invalid choice! Select between 1 and 4." << std::endl;
        }
    }
}

void AppController::editCurrentRestaurantInfo(Restaurant* restaurant) 
{
    if (!restaurant) return;
    
    while (true) {
        std::cout << "\n==================================" << std::endl;
        std::cout << "     EDIT RESTAURANT INFO         " << std::endl;
        std::cout << "==================================" << std::endl;
        std::cout << "Current Name: " << restaurant->getName() << std::endl;
        std::cout << "Current Address: " << restaurant->getAddress() << std::endl;
        std::cout << "Current Phone: " << restaurant->getPhoneNumber() << std::endl;
        std::cout << "----------------------------------" << std::endl;
        std::cout << "1. Change Restaurant Name\n";
        std::cout << "2. Change Restaurant Address\n";
        std::cout << "3. Change Restaurant Phone\n";
        std::cout << "4. Back to Manager Panel\n";
        std::cout << "Selection: ";
        
        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }
        std::cin.ignore(10000, '\n'); // پاک کردن بافر اینتر
        
        if (choice == 4) break; // بازگشت به منوی قبل

        if (choice == 1) {
            std::string newName;
            std::cout << "Enter new restaurant name: ";
            std::getline(std::cin, newName);
            if (!newName.empty()) {
                restaurant->setName(newName);
                // 🔹 ذخیره زنده در دیتابیس
                if (restaurantDAO) restaurantDAO->updateRestaurant(restaurant);
                std::cout << "✅ Name updated successfully in Database!" << std::endl;
            }
        } 
        else if (choice == 2) {
            std::string newAddress;
            std::cout << "Enter new restaurant address: ";
            std::getline(std::cin, newAddress);
            if (!newAddress.empty()) {
                restaurant->setAddress(newAddress);
                // 🔹 ذخیره زنده در دیتابیس
                if (restaurantDAO) restaurantDAO->updateRestaurant(restaurant);
                std::cout << "✅ Address updated successfully in Database!" << std::endl;
            }
        } 
        else if (choice == 3) {
            std::string newPhone;
            std::cout << "Enter new phone number: ";
            std::getline(std::cin, newPhone);
            if (!newPhone.empty()) {
                restaurant->setPhoneNumber(newPhone);
                // 🔹 ذخیره زنده در دیتابیس
                if (restaurantDAO) restaurantDAO->updateRestaurant(restaurant);
                std::cout << "✅ Phone number updated successfully in Database!" << std::endl;
            }
        } 
        else {
            std::cout << "❌ Invalid choice!" << std::endl;
        }
    }
}





// Customer Menu
void AppController::showCustomerMenu()
{ 
    if (currentCustomer == nullptr) //baray in ke age karbari nabod ghati nakone
    {
        std::cout << "\n Wait a minute! You need to login first to access the Customer Panel!\n";
        return;//khoroj baray jologiri kardan az ghati kardan barname 
    }

    for (auto* res : restaurants) {
        delete res;
    }
    restaurants.clear();

    // 🔹 حالا لیست تازه و آپدیت شده را از دیتابیس بکش بیرون
    if (restaurantDAO) {
        restaurants = restaurantDAO->getAllRestaurants();
    }

    // 🔹 [تغییر جدید] لود کردن منوی غذاها و نوشیدنی‌ها برای هر رستوران از دیتابیس
    if (menuItemDAO) { 
        for (auto* res : restaurants) {
            if (res != nullptr) {
                // خواندن آیتم‌های منوی این رستوران خاص از دیتابیس
                std::vector<MenuItem*> items = menuItemDAO->getMenuItemsByRestaurant(res->getId());
                
                // انتقال آیتم‌ها به وکتور داخلیِ خود رستوران
                for (auto* item : items) {
                    if (item != nullptr) {
                        res->addMenuItem(res->getId(), item);
                    }
                }
            }
        }
    }

    if (restaurants.empty()) 
    {
        std::cout << "Sorry! There are no restaurants available." << std::endl;
        return;
    }

    std::cout << "\n--- Select a Restaurant ---\n"; // baray entekhab restaurant morednazar
    for (size_t i = 0; i < restaurants.size(); i++) 
    {
        std::cout << i + 1 << ". " << restaurants[i]->getName() << "\n"
        << " (address " << restaurants[i]->getAddress() << ")" << std::endl;
    }

    std::cout << "0. Back to Main Menu\n";

    int restChoice;
    std::cout << "Select option: ";
    std::cin >> restChoice;

    if (restChoice == 0) return; // bargasht b menu asli
    if (restChoice < 1 || restChoice > restaurants.size()) // etebar sanji entekhab karbar
    {
        std::cout << "Invalid choice!\n";
        return;
    }

    Restaurant* selected= restaurants[restChoice - 1];//resturan entekhab shode ro bardar

    int choice = 0;
    while (choice != 5) 
    {
        std::cout << "\n--- Customer Panel ---\n";
        std::cout << "Your Current Balance: $" << currentCustomer->getWallet() << "\n";//namayesh mojodi kifpol
        std::cout << "1. View Restaurant Menu\n";
        std::cout << "2. Place Order\n";
        std::cout << "3. View Order History\n";
        std::cout << "4. Charge Wallet\n"; 
        std::cout << "5. Back to Main Menu\n";
        std::cout << "Select option: ";
        std::cin >> choice;

        switch (choice) 
        {
            case 1:
                if (!selected->getIsActive()) 
                {
                    std::cout << "Sorry! The restaurant is currently closed.\n";
                } else 
                {
                    selected->displayMenu();
                }
                break;
            case 2:
                if (!selected->getIsActive()) 
                {
                    std::cout << "Cannot place order! The restaurant is closed.\n";
                } else 
                {
                    std::cout << "\n--- Ordering Menu ---\n";
                    selected->displayMenu(); 

                    bool ordering = true;
                    int cartChoice = -1;

                    // --- نیمه اول: حلقه مدیریت و پر کردن سبد خرید ---
                    while (ordering) {
                        std::cout << "\n--- Cart Menu ---\n";
                        std::cout << "Live Total: $" << currentCustomer->getTotal() << "\n"; 
                        std::cout << "1. Add Item (by ID)\n";
                        std::cout << "2. Remove Item (by ID)\n";
                        std::cout << "3. Finalize & Checkout\n";
                        std::cout << "0. Cancel Order\n";
                        std::cout << "Choose an action: ";
                        std::cin >> cartChoice;
                        
                        if (cartChoice == 1) {
                            int foodId;
                            std::cout << "Enter Food ID to ADD: ";
                            std::cin >> foodId;
                            
                            MenuItem* item = selected->findMenuItem(foodId);
                            if (item) {
                                int qty;
                                std::cout << "How many? ";
                                std::cin >> qty;
                                if (qty > 0) {
                                    for(int i=0; i < qty; ++i) {
                                        currentCustomer->addToCart(item);
                                    }
                                    std::cout << " " << qty << " Item(s) added to cart!\n";
                                } else {
                                    std::cout << "❌ Quantity must be greater than zero!\n";
                                }
                            } else {
                                std::cout << " ❌ Invalid Food ID!\n";
                            }
                        }
                        else if (cartChoice == 2) {
                            int foodId;
                            std::cout << "Enter Food ID to REMOVE: ";
                            std::cin >> foodId;
                            currentCustomer->removeFromCart(foodId);
                            std::cout << " Item removed (if existed).\n";
                        }
                        else if (cartChoice == 3) {
                            ordering = false; 
                        }
                        else if (cartChoice == 0) {
                            currentCustomer->clearCart(); 
                            std::cout << "Order cancelled!\n";
                            break; 
                        }
                        else {
                            std::cout << "Invalid choice! Try again.\n";
                        }
                    }

                    if (cartChoice == 0) {
                        break; 
                    }

                    // --- نیمه دوم: بخش تایید نهایی فاکتور و ثبت واقعی سفارش ---
                    double totalAmount = currentCustomer->getTotal();
                    if (totalAmount > 0) {
                        
                        std::cout << "\n=========================================\n";
                        std::cout << "       🧾 FINAL INVOICE (FAKTOR)        \n";
                        std::cout << "=========================================\n";
                        std::cout << "💰 Total Amount to Pay: $" << totalAmount << "\n";
                        std::cout << "=========================================\n";
                        
                        std::string confirm;
                        while (true) {
                            std::cout << "Do you want to finalize this order? (yes/no): ";
                            std::cin >> confirm;
// 🔹 اصلاح عملگرهای منطقی (||) که جا افتاده بودند
                            if (confirm == "yes" || confirm == "YES" || confirm == "Yes" || confirm == "y" ||
                                confirm == "no" || confirm == "NO" || confirm == "No" || confirm == "n") {
                                break; 
                            }
                            
                            std::cout << "❌ Invalid input! Please enter 'yes' or 'no'.\n";
                        }
                        
                        if (confirm == "yes" || confirm == "YES" || confirm == "Yes" || confirm == "y") {
                            
                            // ۱. کسر پول از کیف پول مشتری در حافظه
                            if (currentCustomer->payForOrder(totalAmount)) { //
                                
                                // ۲. به‌روزرسانی دیتابیس مشتری با موجودی جدید
                                if (customerDAO) {
                                    customerDAO->updateWallet(currentCustomer->getCustomerId(), currentCustomer->getWallet()); //
                                }
                                
                                // ۳. 🔹 ثبت سفارش در دیتابیس برای اصلاح آمار ادمین همراه با انتقال غذاها 🔹
                                if (orderDAO) {
                                    // ساخت شیء سفارش (آی‌دی سفارش، آی‌دی مشتری، آی‌دی رستوران)
                                    Order* newOrder = new Order(0, currentCustomer->getCustomerId(), selected->getId());
                                    
                                    // انتقال دانه دانه آیتم‌های سبد خرید به شیء سفارش برای محاسبه قیمت واقعی
                                    for (MenuItem* item : currentCustomer->getCart()) {
                                        newOrder->addItem(item);
                                    }
                                    
                                    // ذخیره در دیتابیس
                                    orderDAO->addOrder(newOrder); 
                                    
                                    // اضافه کردن به تاریخچه محلی
                                    currentCustomer->addOrderToHistory(newOrder); 
                                }
                                
                                currentCustomer->clearCart(); 
                            }
                            
                        } else {
                            std::cout << "❌ Order cancelled. Items remain in your cart.\n";
                        }
                    } else {
                        std::cout << "Your cart is empty. No order placed.\n";
                    }
                }
                break;



            case 3:
                currentCustomer->displayOrderHistory();
                break;
            
            case 4: 
            {
                double amount;
                std::cout << "Enter the amount to add to your wallet: ";
                std::cin >> amount;

                // 🔹 جلوگیری از ورود حروف الفبا یا قفل شدن cin
                if (std::cin.fail()) {
                    std::cin.clear(); // پاک کردن وضعیت خطای cin
                    std::cin.ignore(10000, '\n'); // نادیده گرفتن ورودی‌های اشتباه قبلی
                    std::cout << "❌ Invalid input! Please enter a valid number.\n";
                    break;
                }

                // 🔹 جلوگیری از وارد کردن مبالغ منفی یا صفر
                if (amount <= 0) {
                    std::cout << "❌ Amount must be greater than zero!\n";
                    break;
                }

                // 🔹 جلوگیری از وارد کردن مبالغ فضایی و غیرمنطقی (مثلاً بیش از ۱۰ میلیون)
                if (amount > 10000000) {
                    std::cout << "❌ Amount is too high! Maximum deposit at once is $10,000,000.\n";
                    break;
                }

                if (amount < 10000) {
                    std::cout << "❌ Amount too low! Minimum deposit is $10000.\n";
                    break;
                }

                // اگر همه شرایط درست بود، پول اضافه و در دیتابیس ذخیره می‌شود
                currentCustomer->addFunds(amount);
                
                if (customerDAO) {
                    customerDAO->updateWallet(currentCustomer->getCustomerId(), currentCustomer->getWallet());
                }
                
                std::cout << "✅ Wallet charged successfully! Your new balance: $" << currentCustomer->getWallet() << "\n";
                break;
            }


            
            case 5:
            {
                std::cout << "Returning to main menu...\n";
                break;
            }
            
            default:
            {
                std::cout << "Invalid choice! Please select 1-5.\n";
                break;
            }
        }
    }
}





void AppController::runRestaurantManagerPanel(Restaurant* restaurant) //safhe modir resturan
{
    int choice;
    while (true) 
    {
        std::cout << "\n==================================" << std::endl;
        std::cout << "   MANAGER PANEL: " << restaurant->getName() << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Edit Restaurant Info" << std::endl;
        std::cout << "2. Manage Menu (Add/Edit/Remove Items)" << std::endl;
        std::cout << "3. View & Process Incoming Orders" << std::endl;
        std::cout << "4. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 4) break;

        switch (choice) 
{
    case 1: editCurrentRestaurantInfo(restaurant); break; 
    
    case 2: manageRestaurantMenu(restaurant); break; 
    
    case 3: viewRestaurantOrders(restaurant); break; 
    
    default: std::cout << "Invalid choice" << std::endl;
}
    }
} 



void AppController::viewRestaurantOrders(Restaurant* restaurant) 
{
    while (true) {
        // First, display all orders for the restaurant
        std::cout << "\n--- Orders for " << restaurant->getName() << " ---" << std::endl;
        bool hasOrders = false;
        for (Order* order : orderDAO->getAllOrders()) {
            if (order->getRestaurantId() == restaurant->getId()) {
                hasOrders = true;
                std::cout << "Order ID: " << order->getOrderId()
                     << " | Customer ID: " << order->getCustomerId()
                     << " | Total: $" << order->getTotalPrice()
                     << " | Status: " << static_cast<int>(order->getStatus()) << std::endl;

                // Optional: Display items in the order
                std::cout << "  Items:" << std::endl;
                for(const auto& item : order->getItems()){
                    std::cout << "    - " << item->getName() << " ($" << item->getBasePrice() << ")" << std::endl;
                }
            }
        }

        if (!hasOrders) {
            std::cout << "No orders found for this restaurant." << std::endl;
        }

        std::cout << "\n------------------------------------" << std::endl;
        std::cout << "Enter Order ID to update status (or 0 to return to menu): ";
        int orderId;
        std::cin >> orderId;

        // Input validation
        if (std::cin.fail()) {
            std::cout << "\n[!] Invalid input. Please enter a number." << std::endl;
            std::cin.clear(); // Clear error flags
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard bad input
            continue; // Go to the next loop iteration
        }


        if (orderId == 0) {
            std::cout << "Returning to the manager menu..." << std::endl;
            break;
        }

        Order* order = orderDAO->findOrderById(orderId);


        if (order != nullptr && order->getRestaurantId() == restaurant->getId()) 
        {
            std::cout << "\nSelect new status for Order ID " << orderId << ":" << std::endl;
            std::cout << "1. Preparing" << std::endl;
            std::cout << "2. Delivering" << std::endl;
            std::cout << "3. Completed" << std::endl;
            std::cout << "4. Canceled" << std::endl;
            std::cout << "Enter your choice: ";
            int statusChoice;
            std::cin >> statusChoice;

            if (std::cin.fail()) {
                std::cout << "\n[!] Invalid input. Please enter a number." << std::endl;
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }

            OrderStatus newStatus;
            bool validChoice = true;
            switch (statusChoice) {
                case 1: newStatus = OrderStatus::Preparing; break;
                case 2: newStatus = OrderStatus::Delivered; break; 
                case 3: newStatus = OrderStatus::Delivered; break; 
                case 4: newStatus = OrderStatus::Cancelled; break;
                default:
                    validChoice = false;
                    std::cout << "\n[X] Invalid choice! Status remains unchanged." << std::endl;
                    break;
            }

            if(validChoice) {
                order->setStatus(newStatus);
                orderDAO->updateOrderStatus(order);
                std::cout << "\n[>>] Success! Order status has been updated." << std::endl;
            }

        } else {
            std::cout << "\n[!] Order with this ID not found or does not belong to your restaurant." << std::endl;
        }
        std::cout << "\nPress Enter to continue...";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the leftover newline from previous cin
        std::cin.get(); // Wait for user to press Enter
    }
}



void AppController::editRestaurantInfo(Restaurant* restaurant) 
{
    // ۱. دریافت تمام رستوران‌ها از دیتابیس
    restaurants = restaurantDAO->getAllRestaurants();
    
    std::cout << "\n--- ALL THE RESTAURANTS ---" << std::endl;
    for (size_t i = 0; i < restaurants.size(); ++i) {
        std::cout << "ID: " << restaurants[i]->getId() << " NAME: " << restaurants[i]->getName() << std::endl;
    }

    int targetId = 0;
    std::string inputStr;

    std::cout << "\n>> ENTER RESTAURANTS ID YOU WANT TO CHANGE IT: ";
    
    // ۲. روش هوشمند و یکپارچه بدون تداخل با بافرِ اینترِ منوی قبلی
    while (std::getline(std::cin, inputStr)) 
    {
        // اصلاح غلط املایی و اضافه شدن ||
        if (inputStr.empty() || inputStr == "\n" || inputStr == "\r") {
            continue; 
        }
        if (inputStr == " ") {
            continue;
        }
        
        
        try {
            targetId = std::stoi(inputStr); // تبدیل رشته به عدد
            break; // آیدی با موفقیت دریافت شد، خروج از حلقه
        } catch (...) {
            std::cout << "❌ Invalid Input! Please enter a valid number: ";
        }
    }

    // ۳. پیدا کردن رستوران بر اساس آیدی وارد شده
    Restaurant* targetRes = nullptr;
    for (size_t i = 0; i < restaurants.size(); ++i) {
        if (restaurants[i]->getId() == targetId) {
            targetRes = restaurants[i];
            break;
        }
    }

    if (!targetRes) {
        std::cout << "❌ Restaurant not found!" << std::endl;
        return;
    }

    // ۴. ورود مستقیم و بدون معطلی به منوی ویرایش اطلاعات
    int choice = 0;
    while (choice != 6) 
    { 
        std::cout << "\n----- Edit Restaurant Information -----" << std::endl;
        std::cout << "Current Name: " << targetRes->getName() << std::endl;
        std::cout << "Current Address: " << targetRes->getAddress() << std::endl;
        std::cout << "Current Phone: " << targetRes->getPhoneNumber() << std::endl;
        std::cout << "Current Prep Time: " << targetRes->getEstimatedPrepTime() << " mins" << std::endl; 
        std::cout << "Current Description: " << targetRes->getDescription() << std::endl;
        std::cout << "---------------------------------------" << std::endl;
        std::cout << "1. Change Restaurant Name" << std::endl;
        std::cout << "2. Change Restaurant Address" << std::endl;
        std::cout << "3. Change Restaurant Phone" << std::endl;
        std::cout << "4. Change Preparation Time" << std::endl;
        std::cout << "5. Change Description" << std::endl;
        std::cout << "6. Back to Admin Panel" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;
        std::cin.ignore(10000, '\n'); // پاک کردن بافر اینتر بعد از عدد منو

        if (choice == 6) break;

        std::string newStrValue;
        int newIntValue;

        switch (choice) {
            case 1:
                std::cout << "Enter new restaurant name: ";
                std::getline(std::cin, newStrValue);
                targetRes->setName(newStrValue);
                break;
            case 2:
                std::cout << "Enter new restaurant address: ";
                std::getline(std::cin, newStrValue);
                targetRes->setAddress(newStrValue);
                break;
            case 3:
                std::cout << "Enter new restaurant phone: ";
                std::getline(std::cin, newStrValue);
                targetRes->setPhoneNumber(newStrValue);  
                break;
            case 4:
                std::cout << "Enter new preparation time (minutes): ";
                if (std::cin >> newIntValue && newIntValue > 0) {
                    targetRes->setEstimatedPrepTime(newIntValue);
                } else {
                    std::cout << "Invalid time!" << std::endl;
                }
                std::cin.ignore(10000, '\n');
break;
            case 5:
                std::cout << "Enter new description: ";
                std::getline(std::cin, newStrValue);
                targetRes->setDescription(newStrValue);
                break;
            default:
                std::cout << "Invalid selection!" << std::endl;
                continue;
        }

        // آپدیت دیتابیس بعد از هر تغییر
        restaurantDAO->updateRestaurant(targetRes);
        std::cout << ">> UPDATE FOR INFORMATION WAS SUCCESSFULLY <<" << std::endl;
    }
}


void AppController::runSystemAdminPanel() //system addmin
{
    int choice;
    while (true) {
        std::cout << "\n====================================" << std::endl;
        std::cout << "      SYSTEM ADMINISTRATOR PANEL     " << std::endl;
        std::cout << "====================================" << std::endl;
        std::cout << "1. Add New Restaurant" << std::endl;
        std::cout << "2. Activate/Deactivate Restaurants" << std::endl;
        std::cout << "3. View System Reports" << std::endl;
        std::cout << "4. Update Information" << std::endl;
        std::cout << "5. Logout" << std::endl;
        std::cout << "Selection: ";
        std::cin >> choice;

        if (choice == 5) break;

        switch (choice) 
        {
            case 1: addNewRestaurant(); break;
            case 2: manageRestaurantActivation(); break;
            case 3: viewSystemReports(); break;
            case 4: selectAndEditRestaurant();break;
            default: std::cout << "Invalid choice" << std::endl;
        }
    }
}
void AppController::addNewRestaurant()
{
    std::string name, address, phone, description, password;
    int prepTime;

    std::cout << "Enter restaurant name: ";
    
    // پاک کردن بافر برای جلوگیری از پرش getline
    std::cin.ignore(10000, '\n'); 
    std::getline(std::cin, name);

    if (name.empty() || name == " ") {
        std::cout << "❌ Error: Restaurant name cannot be empty!\n";
        return; 
    }

    std::cout << "Enter address: ";
    std::getline(std::cin, address);

    std::cout << "Enter phone: ";
    std::getline(std::cin, phone);

    std::cout << "Enter description: ";
    std::getline(std::cin, description);

    std::cout << "Enter preparation time (minutes): ";
    while (!(std::cin >> prepTime) || prepTime <= 0) {
        std::cout << "❌ Invalid input! Please enter a positive number for minutes: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    std::cin.ignore(10000, '\n'); 

    // دریافت پسورد مدیر رستوران از ادمین
    std::cout << "Enter Password for Restaurant Manager: ";
    std::getline(std::cin, password);

    // ساخت رستوران با استفاده از سازنده‌ای که پسورد را نیز می‌گیرد
    Restaurant* newRes = new Restaurant(0, name, address, prepTime, phone, description, true, nullptr, nullptr, password);
    
    // اضافه کردن به دیتابیس
    restaurantDAO->addRestaurant(newRes);
    
    // اضافه کردن به لیست رم
    restaurants.push_back(newRes);

    std::cout << "✅ Restaurant \"" << name << "\" added successfully to the system!" << std::endl;
    std::cout << "New ID: " << newRes->getId() << std::endl;
}



void AppController::viewSystemReports() //gozareshat
{
    std::cout << "\n========== SYSTEM REPORT ==========" << std::endl;
    restaurants = restaurantDAO->getAllRestaurants(); 

    std::cout << "Total Restaurants: " << restaurants.size() << std::endl;
    
    int activeCount = 0;
    for (size_t i = 0; i < restaurants.size(); ++i)
    {
        Restaurant* res = restaurants[i];
        if (res && res->getIsActive())
            ++activeCount;
    }
    
    std::cout << "Active Restaurants: " << activeCount << std::endl;
    std::cout << "Inactive Restaurants: " << restaurants.size() - activeCount << std::endl;
    
    // -----------------------------------------------------------------
    // 🔴 بخش جدید: محاسبه آمار سفارشات و مبالغ فروش زنده از دیتابیس
    std::cout << "-----------------------------------" << std::endl;
    
    // ۱. گرفتن تمام سفارشات با استفاده از متد آماده خودت
    std::vector<Order*> allOrders = orderDAO->getAllOrders(); 
    std::cout << "Total Orders Placed: " << allOrders.size() << std::endl;
    
    // ۲. محاسبه مجموع کل فروش سامانه به روش محاسبه مستقیم از روی آیتم‌ها
    double totalSalesAmount = 0.0;
    for (size_t i = 0; i < allOrders.size(); ++i) {
        if (allOrders[i]) {
            // 🔹 اصلاح باگ: صدا زدن متد محاسبه مستقیم برای اینکه قیمت صفر نشان داده نشود
            totalSalesAmount += allOrders[i]->calculateTotalPrice(); 
        }
    }
    std::cout << "Total Sales Amount: " << totalSalesAmount << " Toman" << std::endl;
    
    // 📜 ۳. نمایش لیست کامل جزئیات سفارشات برای ادمین (چیزی که خواسته بودی)
    if (!allOrders.empty()) {
        std::cout << "-----------------------------------" << std::endl;
        std::cout << "       🧾 ALL ORDERS DETAILS 🧾" << std::endl;
        std::cout << "-----------------------------------" << std::endl;
        std::cout << "Order ID | Customer ID | Restaurant ID | Total Price" << std::endl;
        std::cout << "-----------------------------------" << std::endl;
        
        for (size_t i = 0; i < allOrders.size(); ++i) {
            if (allOrders[i]) {
                std::cout << "   " << allOrders[i]->getOrderId() << "     |      " 
                          << allOrders[i]->getCustomerId() << "      |       " 
                          << allOrders[i]->getRestaurantId() << "       | " 
                          << allOrders[i]->getTotalPrice() << " Toman" << std::endl;
            }
        }
    } else {
        std::cout << "No orders registered in the system yet." << std::endl;
    }
    // -----------------------------------------------------------------

    std::cout << "===================================" << std::endl;
}



Customer* AppController::findCustomerById(int id) 
{
    return customerDAO->findCustomerById(id);
}

void AppController::addMenuItemToRestaurant(int restId, MenuItem* item) 
{
    if (item) 
    {

         menuItemDAO->addMenuItem(restId, item);
    }
}

void AppController::addOrder(Order* o) 
{
    if (o) 
    {
        orderDAO->addOrder(o);
    }
}

std::vector<Customer*> AppController::getAllCustomers() 
{
    return customerDAO->getAllCustomers();
}

std::vector<Restaurant*> AppController::getAllRestaurants() 
{
    return restaurants;
}

std::vector<MenuItem*> AppController::getAllMenuItemsForRestaurant(int restId) 
{
    return menuItemDAO->getMenuItemsByRestaurant(restId);
}

void AppController::removeMenuItemById(int id) 
{
    for (auto res : restaurants) 
    {
        res->removeMenuItem(id);
    }
    menuItemDAO->removeMenuItem(id);
}

void AppController::managerAddFoodItem(Restaurant* restaurant) 
{
    if (!restaurant) return;
    
    std::string name, description;
    double price;
    int typeChoice;
    
    std::cout << "\n--- Add New Item to Menu ---" << std::endl;
    std::cout << "Select Type (1. Food | 2. Drink | 3. Dessert): ";
    std::cin >> typeChoice;
    std::cin.ignore(10000, '\n');
    
    std::cout << "Enter Name: ";
    std::getline(std::cin, name);
    
    std::cout << "Enter Price: ";
    std::cin >> price;
    std::cin.ignore(10000, '\n');
    
    std::cout << "Enter Description: ";
    std::getline(std::cin, description);
    
    MenuItem* newItem = nullptr;

    if (typeChoice == 1) { // اگر غذا بود
        int cookTime;
        char vegChar;
        bool isVeg = false;
        
        std::cout << "Enter Cooking Time (minutes): ";
        std::cin >> cookTime;
        std::cout << "Is it Vegetarian? (y/n): ";
        std::cin >> vegChar;
        std::cin.ignore(10000, '\n');
        if (vegChar == 'y' || vegChar == 'Y') isVeg = true;
        
        // ساخت شیء غذا با مشخصات وارد شده
        newItem = new FoodItem(0, name, description, price, true, cookTime, isVeg);
        
    } else if (typeChoice == 2) { // اگر نوشیدنی بود
        char iceChar;
        bool isCold = false;
        double volume;
        
        std::cout << "Is it Ice/Cold Drink? (y/n): ";
        std::cin >> iceChar;
        if (iceChar == 'y' || iceChar == 'Y') isCold = true;
        
        std::cout << "Enter Volume (e.g., 0.33 or 0.5): ";
        std::cin >> volume;
        std::cin.ignore(10000, '\n');
        
        // ساخت شیء واقعی نوشیدنی با توجه به هدر DrinkItem.h
        newItem = new DrinkItem(ItemType::DRINK, 0, name, description, price, true, volume, isCold); 
        
    } else { // دسر
        double sugarLevel;
        
        std::cout << "Enter Sugar Level percentage (e.g., 10 or 25.5): ";
        std::cin >> sugarLevel;
        std::cin.ignore(10000, '\n');
        
        // ساخت شیء واقعی دسر با توجه به هدر DessertItem.h
        newItem = new DessertItem(ItemType::DESSERT, 0, name, description, price, true, sugarLevel);
    }
    
    if (newItem) {
        menuItemDAO->addMenuItem(restaurant->getId(), newItem);
        std::cout << "✅ Item added successfully!" << std::endl;
    }
}



void AppController::managerUpdateItem(Restaurant* restaurant) 
{
    if (!restaurant) return;
    
    std::cout << "\n==================================" << std::endl;
    std::cout << "       UPDATE FOOD ITEM           " << std::endl;
    std::cout << "==================================" << std::endl;
    
    // ۱. گرفتن تمام غذاهای این رستوران مشخص از دیتابیس
    std::vector<MenuItem*> items = menuItemDAO->getMenuItemsByRestaurant(restaurant->getId());
    if (items.empty()) {
        std::cout << "⚠️ Your menu is empty! Nothing to update." << std::endl;
        return;
    }
    
    // ۲. نمایش لیست غذاها به همراه آی‌دی به مدیر
    std::cout << "\n--- Available Items for Update ---" << std::endl;
    for (size_t i = 0; i < items.size(); ++i) {
        std::cout << "ID: " << items[i]->getId() 
                  << " | Name: " << items[i]->getName() 
                  << " | Price: " << items[i]->getBasePrice() << std::endl;
    }
    
    int itemId;
    std::cout << "\nEnter Item ID to update: ";
    std::cin >> itemId;
    std::cin.ignore(10000, '\n'); // پاک کردن بافر اینتر
    
    // پیدا کردن غذای انتخاب شده در بین لیست
    MenuItem* itemToUpdate = nullptr;
    for (auto* it : items) {
        if (it->getId() == itemId) {
            itemToUpdate = it;
            break;
        }
    }
    
    if (!itemToUpdate) {
        std::cout << "❌ Item not found with the given ID!" << std::endl;
        return;
    }
    
    // ۳. دریافت مشخصات جدید غذا از کاربر
    std::string newName;
    std::cout << "Current Name: " << itemToUpdate->getName() << " -> Enter new name (Leave empty to keep): ";
    std::getline(std::cin, newName);
    if (!newName.empty()) itemToUpdate->setName(newName);
    
    double newPrice;
    std::cout << "Current Price: " << itemToUpdate->getBasePrice() << " -> Enter new price (0 to keep): ";
    std::cin >> newPrice;
    std::cin.ignore(10000, '\n');
    if (newPrice > 0) itemToUpdate->setBasePrice(newPrice);
    
    // ۴. فرستادن آیتم تغییریافته به دیتابیس (همان متدِ داخل عکس شما)
    menuItemDAO->updateMenuItem(itemToUpdate);
}


// =================================================================
// ۳. متد حذف آیتم (کاملاً منطبق با ساختار دیتابیس شما)
// =================================================================
void AppController::managerRemoveItem(Restaurant* restaurant) 
{
    if (!restaurant) return;
    
    std::cout << "\n--- Remove Food Item from " << restaurant->getName() << " ---" << std::endl;
    
    // لود کردن مستقیم آخرین وضعیت دیتابیس
    std::vector<MenuItem*> items = menuItemDAO->getMenuItemsByRestaurant(restaurant->getId());
    if (items.empty()) {
        std::cout << "Your menu is empty!" << std::endl;
        return;
    }
    
    for (size_t i = 0; i < items.size(); ++i) {
        std::cout << "ID: " << items[i]->getId() << " | Name: " << items[i]->getName() << " | Price: " << items[i]->getBasePrice() << std::endl;
    }
    
    int itemId;
    std::cout << "Enter Item ID to remove: ";
    if (!(std::cin >> itemId)) {
        for (auto* it : items) delete it;
        std::cin.clear();
        std::cin.ignore(10000, '\n');
        return;
    }
    std::cin.ignore(10000, '\n');
    
    // صدا زدن متد حذف دیتابیس
    menuItemDAO->removeMenuItem(itemId);
    
    // پاکسازی حافظه موقت لود شده
    for (auto* it : items) delete it;
}






AppController::~AppController()
{
    // azad sazi hafede resturan ha
    for (size_t i = 0; i < restaurants.size(); ++i) {
        delete restaurants[i];
    }
    restaurants.clear();
    
}
void AppController::customerLoginMenu() 
{
    bool isLoggedIn = false;
    
    while (true) 
    { 
        std::cout << "\n=========================================\n";
        std::cout << "      🍔 Welcome to Customer Portal 🍔      \n";
        std::cout << "=========================================\n";
        std::cout << "1. Login (vorod)\n";
        std::cout << "2. Sign Up (sabt nam)\n";
        std::cout << "0. Back to Main Menu (bazgasht)\n";
        std::cout << "Enter your choice: ";
        
        int choice;
        std::cin >> choice;
        
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "\n❌ Voroodi namotabar! Lotfan faghat adad vared konid.\n";
            continue;
        }

        if (choice == 1) 
        {
            isLoggedIn = customerLogin(); 
            if (isLoggedIn) {
                
                showCustomerMenu(); // ورود به پنل مشتری بعد از لاگین موفق
                
                delete currentCustomer; 
                currentCustomer = nullptr; // ریست کردن برای نفر بعدی
                isLoggedIn = false; 
            } 
        } // <--- این آکولادِ نجات‌بخش جا افتاده بود! 🦸‍♂️
        else if (choice == 2) 
        {
            if (customerSignup()) 
            {
                std::cout << "\n✅ Sabt nam anjam shod! Hata mitavanid Login konid.\n";
            }
        } // <--- این یکی هم همینطور! 🦸‍♀️
        else if (choice == 0) 
        {
            break; // خروج از حلقه و بازگشت به منوی اصلی
        } 
        else 
        {
            std::cout << "\n❌ Entekhab eshtebah ast! Dastet khord be keyboard? Dobare emtehan kon!\n";
        }
    } 
}


bool AppController::customerSignup() 
{
    std::string name;
    std::string password; // 🔹 تعریف متغیر پسورد
    
    std::cout << "\n--- 📝 Customer Sign Up (Sabt Nam) ---\n";
    
    if (std::cin.peek() == '\n') std::cin.ignore();

    while (true) {
        std::cout << "Enter Name (Nam-e shoma): ";
        std::getline(std::cin, name);
        if (!name.empty()) break;
        std::cout << "❌ Name cannot be empty!\n";
    }

    // 🔹 دریافت پسورد
    std::cout << "Enter Password (only numbers): ";
    std::getline(std::cin, password);

    // ساخت مشتری با ۴ پارامتر (id=0، نام، موجودی=0، پسورد)
    Customer* newCustomer = new Customer(0, name, 0.0f, password);
    
    if (customerDAO) {
        customerDAO->addCustomer(newCustomer);
        // 🔹 نمایش آیدی تولید شده توسط دیتابیس
        std::cout << "\n✅ Sabt nam anjam shod! ID-e shoma: " << newCustomer->getCustomerId() << std::endl;
        std::cout << "Yaddasht konid! 📝\n";
    }
    
    delete newCustomer; 
    return true;
}



bool AppController::customerLogin() 
{
    int inputId;
    std::string inputName;
    std::string inputPass; // 🔹 تعریف متغیر پسورد
    
    std::cout << "\n--- 🔐 Customer Login (Vorood) ---\n";
    std::cout << "Enter Customer ID (Shenase): ";
    std::cin >> inputId;
    
    if (std::cin.fail()) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "\n❌ Shenase bayad adad bashe!\n";
        return false;
    }

    std::cout << "Enter Name: ";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
    std::getline(std::cin, inputName);

    // 🔹 دریافت پسورد
    std::cout << "Enter Password: ";
    std::getline(std::cin, inputPass);

    std::vector<Customer*> allCustomers = customerDAO->getAllCustomers(); 
    Customer* foundCustomer = nullptr; 

    for (auto* c : allCustomers) {
        // 🔹 بررسی سه فاکتور: ID و Name و Password
        if (c->getCustomerId() == inputId && c->getName() == inputName && c->getPassword() == inputPass) 
        { 
            foundCustomer = c; 
            break; 
        }
    }

    if (foundCustomer) 
    {
        currentCustomer = new Customer(*foundCustomer); 
        std::cout << "\n🎉 Login movafaghiyat amiz bood! Khosh amadid, " << currentCustomer->getName() << "! 🎉\n";
        
        for (auto* customer : allCustomers) delete customer;
        allCustomers.clear(); 
        return true; 
    } else {
        std::cout << "\n❌ Khata: ID, Name ya Password eshtebah ast!\n";
        for (auto* c : allCustomers) delete c;
        allCustomers.clear();
        return false;
    }
}



void AppController::selectAndEditRestaurant() {
    std::vector<Restaurant*> restaurants = restaurantDAO->getAllRestaurants();
    if (restaurants.empty()) {
        std::cout << "\n>>THERE ISNT ANY THING HERE TO REFRESH \n";
        return;
    }

    std::cout << "\n--- ALL THE RESTAURANTS ---\n";
    for (const auto& restaurant : restaurants) 
    {
        if (restaurant != nullptr) { //baray in ke barname crash nakone
            std::cout << "ID: " << restaurant->getId() << " NAME: " << restaurant->getName() << std::endl;
        }
    }


    int targetId;
    std::cout << "\n>> ENTER RESTAURANTS ID YOU WANT TO CHANGE IT ";
    std::cin >> targetId;

    // check kardan inke vorodi ada bashe
    if (std::cin.fail()) {
        std::cin.clear(); // pak kardan flag khata
        std::cin.ignore(10000, '\n'); // khali kardan bafer vorodi
        std::cout << "\n>> !!!JUST ENTER NUMBER!!!\n";
        return;
    }
    
    //pak kardan bafer baray getline
    std::cin.ignore(10000, '\n'); 

    Restaurant* selectedRestaurant = nullptr;
    for (auto& restaurant : restaurants) 
    {
        if (restaurant != nullptr && restaurant->getId() == targetId) {
            selectedRestaurant = restaurant;
            break;
        }
    }

    if (selectedRestaurant) {
        // hala ke resturan ro peyda kardim tabe asli virayesh ro seda mizanim
        editRestaurantInfo(selectedRestaurant);
        std::cout << "\n>> **UPDATE FOR INFORMATION WAS SECCUSFULLY**\n";
    } else {
        std::cout << "\n>>!! WE CANT FIND A RESTAURANT WHITH THIS ID!!\n";
    }
}

void AppController::managerLoginMenu() 
{
    // ۱. لود کردن رستوران‌ها
    restaurants = restaurantDAO->getAllRestaurants(); 

    int restId;
    std::cout << "\n--- 👨‍🍳 Manager Login ---\n";
    std::cout << "Enter your Restaurant ID: ";
    
    // 🛡️ جلوگیری از کرش در صورت وارد کردن حروف (ایمن)
    while (!(std::cin >> restId)) {
        std::cout << "❌ Invalid ID! Please enter a numeric ID: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    std::cin.ignore(10000, '\n'); // پاک کردن اینتر اضافه

    // ۲. پیدا کردن رستوران در لیست
    Restaurant* targetRest = nullptr;
    for (size_t i = 0; i < restaurants.size(); ++i) {
        if (restaurants[i]->getId() == restId) {
            targetRest = restaurants[i];
            break;
        }
    }
    
    // ۳. بررسی وجود رستوران و چک کردن پسورد
    if (targetRest != nullptr) {
        std::string inputPassword;
        std::cout << "Enter your Password: ";
        std::getline(std::cin, inputPassword); // خواندن ایمن پسورد

        // چک کردن رمز عبور (که در دیتابیس ذخیره شده)
        if (inputPassword == targetRest->getPassword()) {
            std::cout << "✅ Login Successful! Welcome " << targetRest->getName() << " manager.\n";
            runRestaurantManagerPanel(targetRest);
        } else {
            std::cout << "❌ Access Denied! Wrong password. 🛑\n";
        }
    } else {
        std::cout << "❌ Restaurant not found! Did aliens abduct it? 👽\n";
    }
   
    for (auto* r : restaurants) {
        delete r;
    }
    restaurants.clear();
}

void AppController::manageRestaurantActivation() 
{
    std::cout << "\n--- 🔄 Manage Restaurant Activation ---\n";
    std::cout << "Enter Restaurant ID to change status: ";
    int restId;
    std::cin >> restId;

    // پیدا کردن رستوران در دیتابیس
    Restaurant* rest = restaurantDAO->findRestaurantById(restId);

    if (rest != nullptr) {
        std::cout << "Restaurant: " << rest->getName() << " | Current Status: " << (rest->getIsActive() ? "Active" : "Inactive") << std::endl;
        std::cout << "Do you want to toggle status? (1 for Yes, 0 for No): ";
        int choice;
        std::cin >> choice;

        if (choice == 1) {
            // تغییر وضعیت در آبجکت
            bool newStatus = !rest->getIsActive();
            rest->setIsActive(newStatus);
            
            // ذخیره تغییرات در دیتابیس (این همان چیزی است که سیستم را کامل می‌کند)
            restaurantDAO->updateRestaurant(rest);
            
            std::cout << "✅ Status updated successfully to: " << (rest->getIsActive() ? "Active" : "Inactive") << std::endl;
        }
    } else {
        std::cout << "❌ Restaurant not found!\n";
    }
}



