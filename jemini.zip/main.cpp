#include "DatabaseManager.h"
#include "DatabaseInitializer.h"
#include "AppController.h"
#include "Restaurant.h"
#include <iostream>
#include <vector>
#include <cstdlib> // برای تابع system

using namespace std;

// ==========================================
//                 MAIN
// ==========================================
int main() 
{
    // جادوی فارسی‌نویسی در ویندوز (UTF-8) 🪄
    system("chcp 65001 > nul");

    // اتصال به دیتابیس (خدا کنه منفجر نشه! 💥)
    DatabaseManager db("food_system.db");

    if (!db.open()) {
        cerr << "Error: Could not open database connection. Did you break it?! 💥" << endl;
        return 1;
    }

    // راه‌اندازی و ساخت جداول در صورت نیاز
    DatabaseInitializer::initialize(db);
    
    // ساخت قلب تپنده‌ی برنامه‌ی ما ❤️
    AppController appController(db);

    int mainChoice;
    do {
        cout << "\n=================================\n";
        cout << "   Welcome to the Food System! 🍽️\n";
        cout << "=================================\n";
        cout << "1. Customer Portal 🍔\n";
        cout << "2. Manager Portal 👨‍🍳\n";
        cout << "3. Admin Portal 👑\n";
        cout << "0. Exit 🏃‍♂️\n";
        cout << "Enter your role: ";
        
        // جلوگیری از کرش کردن برنامه اگر کاربر به جای عدد، حرف وارد کرد! 🛡️
        if (!(cin >> mainChoice)) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Numbers only, my friend! We don't speak alphabet here. 🧐\n";
            continue;
        }

        switch (mainChoice) 
        {
            case 1: 
                // واگذاری تمام کارهای مشتری به متد مخصوص خودش توی کنترلر
                // اصلاح شد: اول باید بره منوی لاگین و ثبت نام! 🚪
                appController.customerLoginMenu(); 
                break;
                
            case 2: {
                int restId;
                cout << "\n--- Manager Login ---\n";
                cout << "Enter your Restaurant ID: ";
                cin >> restId;
                
                // پیدا کردن رستوران مدیر از لیست رستوران‌ها
                vector<Restaurant*> allRest = appController.getAllRestaurants();
                Restaurant* targetRest = nullptr;
                for (auto* r : allRest) {
                    if (r->getId() == restId) {
                        targetRest = r;
                        break;
                    }
                }
                
                if (targetRest != nullptr) {
                    // حالا منوی پیشرفته مدیر رو صدا می‌زنیم! 😎
                    // متد runRestaurantManagerPanel توی AppController تمام آپشن‌های مدیریتی رو داره
                    appController.runRestaurantManagerPanel(targetRest);
                } else {
                    cout << "Restaurant not found! Did aliens abduct it? 👽\n";
                }
                break;
            }
                
            case 3: 
                // واگذاری منوی ادمین کل سیستم
                appController.runSystemAdminPanel(); 
                break;
                
            case 0: 
                cout << "Goodbye! Have a delicious day! 👋\n"; 
                break;
                
            default: 
                cout << "Invalid choice! Try again, my friend. 🧐\n";
        } 
        
    } while (mainChoice != 0);
    
    return 0;
}
