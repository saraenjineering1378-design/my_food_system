#include "DatabaseManager.h"
#include "DatabaseInitializer.h"
#include "AppController.h"
#include "Customer.h"
#include "Restaurant.h"
#include "MenuItem.h"
#include "Order.h"
#include "Enums.h" // برای ItemType
#include <string>
#include <vector>
#include <cstdlib> // برای تابع system

using namespace std;

// ==========================================
//                 Customer Menu
// ==========================================
void handleCustomerMenu(AppController& appController) {
    int choice;
    do {
        std::cout << "\n--- 🍔 Customer Portal ---\n";
        std::cout << "1. View All Restaurants\n";
        std::cout << "0. Back to Main Menu\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        if (choice == 1) {
            std::cout << "\n--- Available Restaurants ---\n";
            vector<Restaurant*> restaurants = appController.getAllRestaurants();
            if (restaurants.empty()) {
                std::cout << "No restaurants found! Time to cook at home! 🍳\n";
            } else {
                for (auto* r : restaurants) {
                    std::cout << "ID: " << r->getId() << " | Name: " << r->getName() << "\n";
                }
            }
        }
    } while (choice != 0);
}

// ==========================================
//                 Manager Menu
// ==========================================
void handleManagerMenu(AppController& appController) {
    int choice;
    do {
        std::cout << "\n--- 👨‍🍳 Manager Portal ---\n";
        std::cout << "1. Add New Menu Item\n";
        std::cout << "0. Back to Main Menu\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

        if (choice == 1) {
            int resId, itemId, typeInt;
            string itemName, description;
            double price;

            std::cout << "Enter your Restaurant ID: ";
            std::cin >> resId;
            std::cout << "Enter new Item ID: ";
            std::cin >> itemId;
            
            std::cout << "Select Item Type (0: Food, 1: Drink, 2: Dessert): ";
            std::cin >> typeInt;
            ItemType itemType = static_cast<ItemType>(typeInt);

            std::cout << "Enter Item Name: ";
            std::cin.ignore();
            getline(std::cin, itemName);
            
            std::cout << "Enter Description: ";
            getline(std::cin, description);

            std::cout << "Enter Price ($): ";
            std::cin >> price;
            
            // ساخت منو آیتم با ۶ تا آرگومان خفنی که کشف کردیم! 😎
            MenuItem* newItem = new MenuItem(itemType, itemId, itemName, description, price, true);
            appController.addMenuItemToRestaurant(resId, newItem);
            
            std::cout << "Yummy! '" << itemName << "' added to the menu! 🍕\n";
        }
    } while (choice != 0);
}

// ==========================================
//                 Admin Menu
// ==========================================
void handleAdminMenu(AppController& appController) 
{
    int choice;
    do {
        std::cout << "\n--- 👑 Admin Portal ---\n";
        std::cout << "1. Add New Restaurant\n";
        std::cout << "2. View All Users (Customers)\n";
        std::cout << "0. Back to Main Menu\n";
        std::cout << "Enter choice: ";
        std::cin >> choice;

               if (choice == 1) {
            // اینجا همه متغیرها رو کامل تعریف می‌کنیم
            int id, prepTime;
            string name, address, phone, description;
            
            std::cout << "Enter Restaurant ID: ";
            std::cin >> id;
            std::cout << "Enter Name: ";
            std::cin.ignore();
            getline(std::cin, name);
            std::cout << "Enter Address: ";
            getline(std::cin, address);
            std::cout << "Enter Phone: ";
            getline(std::cin, phone);
            
            // این دو تا خط رو یادت رفته بود! 👇
            std::cout << "Enter Estimated Prep Time (minutes): ";
            std::cin >> prepTime;
            std::cout << "Enter Description: ";
            std::cin.ignore();
            getline(std::cin, description);

            // حالا با خیال راحت می‌سازیمش
            Restaurant* newRes = new Restaurant(id, name, address, prepTime, phone, description);
            appController.addRestaurant(newRes);
            std::cout << "Restaurant '" << name << "' created successfully! 🎉\n";
        

        } else if (choice == 2) {
            cout << "\n--- All Users ---\n";
            vector<Customer*> customers = appController.getAllCustomers();
            if (customers.empty()) {
                cout << "No users found! It's a ghost town! 👻\n";
            } else {
                for (auto* c : customers) {
                    // استفاده از متدهای درست کلاس Customer
                    cout << "ID: " << c->getCustomerId() << " | Name: " << c->getName() << " | Wallet: $" << c->getWallet() << "\n";
                }
            }
        }
    } while (choice != 0);
}


// ==========================================
//                 MAIN
// ==========================================
int main() 
{

    // جادوی فارسی‌نویسی در ویندوز (UTF-8) 🪄
    system("chcp 65001 > nul");

    DatabaseManager db("food_system.db");

    if (!db.open()) {
        cerr << "Error: Could not open database connection. Did you break it?! 💥" << endl;
        return 1;
    }

    DatabaseInitializer::initialize(db);
    AppController appController(db);

    int mainChoice;
    do {
        cout << "\n=================================\n";
        cout << "   Welcome to the Food System! 🍽️\n";
        cout << "=================================\n";
        cout << "1. Customer Portal\n";
        cout << "2. Manager Portal\n";
        cout << "3. Admin Portal\n";
        std::cout << "0. Exit\n";
        std::cout << "Enter your role: ";
        std::cin >> mainChoice;

        switch (mainChoice) 
        {
            case 1: handleCustomerMenu(appController); break;
            case 2: handleManagerMenu(appController); break;
            case 3: handleAdminMenu(appController); break;
            case 0: cout << "Goodbye! Have a delicious day! 👋\n"; break;
            default: cout << "Invalid choice! Try again, my friend. 🧐\n";
        
        } 
        }while (mainChoice != 0);
    

    return 0;
}
