#include <iostream>
#include <vector>
#include "SQLiteRestaurantDAO.h"
#include <sstream>



std::vector<Restaurant*> SQLiteRestaurantDAO::getAllRestaurants() const
{
    std::vector<Restaurant*> list;
    std::string sql = "SELECT * FROM Restaurants;";
    
    auto rows = dbManager.fetchAll(sql);
    
    for (size_t i = 0; i < rows.size(); i++) 
    {
    // gereftan map marbot be radif feli
    std::map<std::string, std::string>& row = rows[i];

    int id = std::stoi(row["id"]);
    std::string name = row["name"];
    std::string address = row["address"];
    std::string phone = row["phoneNumber"];
    bool active = (std::stoi(row["isActive"]) != 0);

    Restaurant* r = new Restaurant(id, name, address, 30, phone, "");
    if (!active) r->deactivate();

    list.push_back(r);
}
    return list;
}

static std::string escapeSql(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (c == '\'') out += "''";
        else out += c;
    }
    return out;
}

void SQLiteRestaurantDAO::addRestaurant(Restaurant* restaurant) 

{
    if (!restaurant) return;

    std::ostringstream sql;
    sql << "INSERT INTO Restaurants (name, address, estimatedPrepTime, phoneNumber, description, isActive) VALUES ('"
        << escapeSql(restaurant->getName()) << "', '"
        << escapeSql(restaurant->getAddress()) << "', "
        << restaurant->getEstimatedPrepTime() << ", '"
        << escapeSql(restaurant->getPhoneNumber()) << "', '"
        << escapeSql(restaurant->getDescription()) << "', "
        << (restaurant->getIsActive() ? 1 : 0)
        << ");";

    if (!dbManager.executeQuery(sql.str())) {
        std::cerr << "addRestaurant failed.\n";
        return;
    }

    int newId = dbManager.getLastInsertId();
    restaurant->setId(newId);
}


void SQLiteRestaurantDAO::updateRestaurant(Restaurant* restaurant) 
{
     if (!restaurant) return; // age rresturani nabod karo motevaghef kon

    std::string sql = "UPDATE Restaurants SET name = ?, address = ?, isActive = ?, estimatedPrepTime = ?, phoneNumber = ?, description = ? WHERE id = ?;";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(dbManager.getDatabase(), sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, restaurant->getName().c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, restaurant->getAddress().c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 3, restaurant->getIsActive() ? 1 : 0);
        sqlite3_bind_int(stmt, 4, restaurant->getEstimatedPrepTime());
        sqlite3_bind_text(stmt, 5, restaurant->getPhoneNumber().c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 6, restaurant->getDescription().c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 7, restaurant->getId());// id baray shart where

        if (sqlite3_step(stmt) != SQLITE_DONE) {
            std::cerr << "Error updating restaurant: " << sqlite3_errmsg(dbManager.getDatabase()) << std::endl;
        }
    }
    sqlite3_finalize(stmt);
}


void SQLiteRestaurantDAO::removeRestaurant(int id) 
{
    std::string sql = "DELETE FROM Restaurants WHERE id = ?;";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(dbManager.getDatabase(), sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, id);
        if (sqlite3_step(stmt) != SQLITE_DONE) {
            std::cerr << "Error deleting restaurant: " << sqlite3_errmsg(dbManager.getDatabase()) << std::endl;
        }
    }
    sqlite3_finalize(stmt);
}


Restaurant* SQLiteRestaurantDAO::findRestaurantById(int id) const 
{
    std::string sql = "SELECT id, name, address, isActive, estimatedPrepTime, phoneNumber, description FROM Restaurants WHERE id = ?;";
    sqlite3_stmt* stmt;
    Restaurant* restaurant = nullptr;

    if (sqlite3_prepare_v2(dbManager.getDatabase(), sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, id);

       //age recordi peyda shod
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            restaurant = new Restaurant(id, "", "", 30, "", "");

            restaurant->setId(sqlite3_column_int(stmt, 0));
            
            // tabdil maghadir matni database be string
            const unsigned char* nameText = sqlite3_column_text(stmt, 1);
            if (nameText) restaurant->setName(reinterpret_cast<const char*>(nameText));
            
            const unsigned char* addressText = sqlite3_column_text(stmt, 2);
            if (addressText) restaurant->setAddress(reinterpret_cast<const char*>(addressText));
            
            restaurant->setIsActive(sqlite3_column_int(stmt, 3) != 0);
            restaurant->setEstimatedPrepTime(sqlite3_column_int(stmt, 4));
            
            const unsigned char* phoneText = sqlite3_column_text(stmt, 5);
            if (phoneText) restaurant->setPhoneNumber(reinterpret_cast<const char*>(phoneText));
            
            const unsigned char* descText = sqlite3_column_text(stmt, 6);
            if (descText) restaurant->setDescription(reinterpret_cast<const char*>(descText));
        }
    }
    sqlite3_finalize(stmt);
    return restaurant; // ya ubject barmigardone ya nullptr
}


